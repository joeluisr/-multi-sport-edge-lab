import test from 'node:test';
import assert from 'node:assert/strict';
import { scanPropBoard } from '../src/propScanner.js';

const sportConfig = { slug: 'nfl', title: 'NFL' };
const now = new Date('2026-09-28T12:00:00Z');

function boardFor({ lines = [84.5, 85.5, 85.5], odds = [[-110,-110],[-105,-115],[-110,-110]] } = {}) {
  const books = {};
  ['a','b','c'].forEach((key, i) => {
    books[key] = {
      bookmaker: `Book ${key.toUpperCase()}`,
      lastUpdate: '2026-09-28T11:50:00Z',
      offers: [{
        line: lines[i],
        outcomes: {
          over: { americanOdds: odds[i][0] },
          under: { americanOdds: odds[i][1] },
        },
      }],
    };
  });
  return {
    games: [{
      gameId: 'g1',
      commenceTime: '2026-09-28T23:15:00Z',
      homeTeam: 'Chicago Bears',
      awayTeam: 'Philadelphia Eagles',
      matchup: 'Philadelphia Eagles @ Chicago Bears',
      markets: {
        player_reception_yds: {
          'Receiver Example': { playerName: 'Receiver Example', books },
        },
      },
    }],
  };
}

test('recent logs + better line can promote a candidate to CORE', async () => {
  const scan = await scanPropBoard({
    sportConfig,
    board: boardFor(),
    now,
    maxEnrichment: 5,
    enrichPlayer: async () => ({
      status: 'ok', source: 'TEST', player: 'Receiver Example', team: 'Philadelphia Eagles', opponent: 'Chicago Bears',
      last10: [100,90,88,86,70,92,91,87,84,83].map((value, i) => ({ date: `2026-09-${27-i}`, value })),
      vsOpponent: [{date:'2025-01-01',value:91},{date:'2024-01-01',value:89},{date:'2023-01-01',value:70}],
    }),
  });
  const over = scan.candidates.find((candidate) => candidate.side === 'over');
  assert.ok(over);
  assert.equal(over.line, 84.5);
  assert.equal(over.marketEvidence.consensusLine, 85.5);
  assert.equal(over.classification, 'CORE');
  assert.equal(over.statsEvidence.last5.hitRate, 0.8);
  assert.equal(over.statsEvidence.last10.hitRate, 0.7);
});

test('market-only evidence is capped at MARKET_WATCH and cannot become CORE', async () => {
  const scan = await scanPropBoard({ sportConfig, board: boardFor(), now, maxEnrichment: 0 });
  assert.ok(scan.candidates.every((candidate) => !['CORE','STRONG','HIGH_VARIANCE_VALUE'].includes(candidate.classification)));
});

test('flat symmetric market with no stats returns PASS rather than forcing a prop', async () => {
  const scan = await scanPropBoard({
    sportConfig,
    board: boardFor({ lines: [84.5,84.5,84.5], odds: [[-110,-110],[-110,-110],[-110,-110]] }),
    now,
    maxEnrichment: 0,
  });
  assert.equal(scan.actionableCount, 0);
  assert.ok(scan.candidates.every((candidate) => candidate.classification === 'PASS'));
});

test('tiny statistical samples cannot promote a market signal to CORE or STRONG', async () => {
  const scan = await scanPropBoard({
    sportConfig,
    board: boardFor(),
    now,
    maxEnrichment: 5,
    enrichPlayer: async () => ({
      status: 'ok', source: 'TEST', player: 'Receiver Example', team: 'Philadelphia Eagles', opponent: 'Chicago Bears',
      last10: [{ date: '2026-09-27', value: 130 }],
      vsOpponent: [],
    }),
  });
  const over = scan.candidates.find((candidate) => candidate.side === 'over');
  assert.ok(over);
  assert.ok(!['CORE','STRONG','HIGH_VARIANCE_VALUE'].includes(over.classification));
  assert.equal(over.dataQuality, 'LIMITED');
});

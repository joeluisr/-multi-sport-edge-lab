import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { spawn } from 'node:child_process';

function listen(server, port) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => resolve());
  });
}

function close(server) {
  return new Promise((resolve) => server.close(() => resolve()));
}

function sendJson(res, payload, headers = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(200, { 'content-type': 'application/json', ...headers });
  res.end(body);
}

async function waitFor(url, timeoutMs = 7000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 75));
  }
  throw new Error(`Timed out waiting for ${url}`);
}

test('automatic scan route combines live market feed and recent logs end-to-end', { timeout: 15000, concurrency: false }, async () => {
  const oddsPort = 45121;
  const bdlPort = 45122;
  const appPort = 45123;
  const future = new Date(Date.now() + 4 * 3600_000).toISOString();

  const oddsServer = http.createServer((req, res) => {
    const url = new URL(req.url, `http://127.0.0.1:${oddsPort}`);
    if (url.pathname === '/v4/sports/americanfootball_nfl/events') {
      return sendJson(res, [{ id: 'g1', commence_time: future, home_team: 'Chicago Bears', away_team: 'Philadelphia Eagles' }]);
    }
    if (url.pathname === '/v4/sports/americanfootball_nfl/events/g1/odds') {
      const bookmakers = [
        ['booka','Book A',84.5,-110,-110],
        ['bookb','Book B',85.5,-105,-115],
        ['bookc','Book C',85.5,-110,-110],
      ].map(([key,title,line,over,under]) => ({
        key,title,last_update:new Date().toISOString(),markets:[{key:'player_reception_yds',last_update:new Date().toISOString(),outcomes:[
          {name:'Over',description:'Example Receiver',price:over,point:line},
          {name:'Under',description:'Example Receiver',price:under,point:line},
        ]}],
      }));
      return sendJson(res, { id:'g1', commence_time:future, home_team:'Chicago Bears', away_team:'Philadelphia Eagles', bookmakers }, {
        'x-requests-remaining': '999', 'x-requests-used': '1', 'x-requests-last': '1',
      });
    }
    res.writeHead(404);res.end();
  });

  const bdlServer = http.createServer((req, res) => {
    const url = new URL(req.url, `http://127.0.0.1:${bdlPort}`);
    if (url.pathname === '/nfl/v1/players') {
      return sendJson(res, { data:[{id:9,first_name:'Example',last_name:'Receiver',team:{id:2,full_name:'Philadelphia Eagles',abbreviation:'PHI'}}] });
    }
    if (url.pathname === '/nfl/v1/stats') {
      const values=[100,90,88,86,70,92,91,87,84,83];
      return sendJson(res, { data:values.map((receiving_yards,index)=>({
        receiving_yards, team:{id:2,full_name:'Philadelphia Eagles'},
        game:{date:new Date(Date.now()-(index+1)*86400_000).toISOString(),home_team:{id:index%3===0?1:2,full_name:index%3===0?'Chicago Bears':'Philadelphia Eagles'},away_team:{id:index%3===0?2:3,full_name:index%3===0?'Philadelphia Eagles':'Dallas Cowboys'}},
      })) });
    }
    res.writeHead(404);res.end();
  });

  await listen(oddsServer, oddsPort);
  await listen(bdlServer, bdlPort);
  const child = spawn(process.execPath, ['server.js'], {
    cwd: new URL('..', import.meta.url).pathname,
    env: {
      ...process.env,
      PORT: String(appPort),
      ODDS_API_KEY: 'test-odds',
      ODDS_API_BASE: `http://127.0.0.1:${oddsPort}/v4`,
      BALLDONTLIE_API_KEY: 'test-bdl',
      BALLDONTLIE_API_BASE: `http://127.0.0.1:${bdlPort}`,
      SCAN_ENRICH_LIMIT: '4',
      PROP_MAX_EVENTS: '5',
      PROP_EVENT_HORIZON_HOURS: '24',
    },
    stdio: ['ignore','pipe','pipe'],
  });

  try {
    await waitFor(`http://127.0.0.1:${appPort}/health`);
    const response = await fetch(`http://127.0.0.1:${appPort}/api/sports/nfl/scan?markets=player_reception_yds`);
    assert.equal(response.status, 200);
    const payload = await response.json();
    assert.equal(payload.feeds.stats.activeForSport, true);
    assert.equal(payload.scan.scannedPlayerMarkets, 1);
    const over = payload.scan.candidates.find((candidate) => candidate.side === 'over');
    assert.ok(over);
    assert.equal(over.classification, 'CORE');
    assert.equal(over.line, 84.5);
    assert.equal(over.marketEvidence.consensusLine, 85.5);
    assert.equal(over.statsEvidence.last10.hitRate, 0.7);
  } finally {
    child.kill('SIGTERM');
    await Promise.all([close(oddsServer), close(bdlServer)]);
  }
});

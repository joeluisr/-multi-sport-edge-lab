import test from 'node:test';
import assert from 'node:assert/strict';
import { enrichPropWithBalldontlie } from '../src/balldontlie.js';

function response(payload) {
  return new Response(JSON.stringify(payload), { status: 200, headers: { 'content-type': 'application/json' } });
}

test('NFL enrichment resolves player, recent values, and opponent history', { concurrency: false }, async () => {
  process.env.BALLDONTLIE_API_KEY = 'test-key';
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    const value = String(url);
    if (value.includes('/nfl/v1/players?')) {
      return response({ data: [{ id: 9, first_name: 'Example', last_name: 'Receiver', team: { id: 2, full_name: 'Philadelphia Eagles', abbreviation: 'PHI' } }] });
    }
    if (value.includes('/nfl/v1/stats?')) {
      return response({ data: [
        { receiving_yards: 91, team: { id: 2, full_name: 'Philadelphia Eagles' }, game: { date: '2026-09-20T17:00:00Z', home_team: { id: 1, full_name: 'Chicago Bears' }, away_team: { id: 2, full_name: 'Philadelphia Eagles' } } },
        { receiving_yards: 74, team: { id: 2, full_name: 'Philadelphia Eagles' }, game: { date: '2026-09-13T17:00:00Z', home_team: { id: 2, full_name: 'Philadelphia Eagles' }, away_team: { id: 3, full_name: 'Dallas Cowboys' } } },
      ] });
    }
    throw new Error(`Unexpected URL ${value}`);
  };
  try {
    const result = await enrichPropWithBalldontlie({
      sport: 'nfl', playerName: 'Example Receiver', market: 'player_reception_yds',
      homeTeam: 'Chicago Bears', awayTeam: 'Philadelphia Eagles', commenceTime: '2026-09-28T23:15:00Z',
    });
    assert.equal(result.status, 'ok');
    assert.deepEqual(result.last10.map((row) => row.value), [91, 74]);
    assert.equal(result.opponent, 'Chicago Bears');
    assert.deepEqual(result.vsOpponent.map((row) => row.value), [91]);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('MLB enrichment converts batting box score into total bases', { concurrency: false }, async () => {
  process.env.BALLDONTLIE_API_KEY = 'test-key';
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    const value = String(url);
    if (value.includes('/mlb/v1/players?')) {
      return response({ data: [{ id: 21, first_name: 'Example', last_name: 'Slugger', team: { id: 14, display_name: 'Los Angeles Dodgers', abbreviation: 'LAD' } }] });
    }
    if (value.includes('/mlb/v1/stats?')) {
      return response({ data: [
        { hits: 2, doubles: 1, triples: 0, home_runs: 0, team: { id: 14, display_name: 'Los Angeles Dodgers' }, game: { date: '2026-09-27T20:00:00Z', home_team: { id: 14, display_name: 'Los Angeles Dodgers' }, away_team: { id: 15, display_name: 'San Francisco Giants' } } },
      ] });
    }
    throw new Error(`Unexpected URL ${value}`);
  };
  try {
    const result = await enrichPropWithBalldontlie({
      sport: 'mlb', playerName: 'Example Slugger', market: 'batter_total_bases',
      homeTeam: 'Los Angeles Dodgers', awayTeam: 'San Francisco Giants', commenceTime: '2026-09-28T20:00:00Z',
    });
    assert.equal(result.status, 'ok');
    assert.equal(result.last10[0].value, 3);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

# Multi-Sport Edge Lab — Automatic Prop Scanner + Clean-Start V3

This release adds an automatic player-prop discovery layer to the multi-sport app while preserving the governance-approved Layer-5 V3 persistence baseline.

## Supported sports

- NFL
- College Football (CFB / NCAAF)
- MLB
- NBA
- WNBA
- NCAAB
- NHL

The sport registry remains centralized in `src/sportConfig.js`.

## Automatic prop scanner

The new **Scan Props** flow:

1. Pulls the current player-prop board from The Odds API.
2. Normalizes books, players, markets, lines, prices, and update times.
3. Compares the same prop across books.
4. Detects favorable line differences and price-shopping opportunities.
5. Computes paired no-vig market support when both Over and Under prices exist.
6. Optionally enriches the strongest player/market groups with BALLDONTLIE recent game logs.
7. Tests the current exact line against Last 5 and Last 10 results.
8. Uses the existing 0.6×Last-5 + 0.4×Last-10 recent-form weighting as a transparent projection aid.
9. Uses vs-current-opponent history when the feed exposes enough game identity to match it.
10. Ranks candidates as `CORE`, `STRONG`, `HIGH_VARIANCE_VALUE`, `MARKET_WATCH`, `WATCH`, or `PASS`.

### Important ranking guardrail

If recent statistical enrichment is unavailable, a candidate **cannot** be labeled `CORE`, `STRONG`, or `HIGH_VARIANCE_VALUE`. Market-only evidence is capped at `MARKET_WATCH`.

The evidence score is a ranking heuristic, **not a calibrated win probability**.

## Data feeds

### Required for live scanning

`ODDS_API_KEY`

Used for current sportsbook player-prop markets. The scanner does not call live market endpoints until you tap **Scan Props** or **Load Live Props**.

### Optional but strongly recommended

`BALLDONTLIE_API_KEY`

Used for recent player game logs in this release for:

- NFL
- CFB / NCAAF
- MLB
- NBA
- WNBA
- NCAAB

NHL currently scans sportsbook market structure but is not promoted by recent-game enrichment in this build.

`SCAN_ENRICH_LIMIT=12` controls how many high-ranked player/market groups get statistical enrichment per scan, which limits provider usage and latency.

## API routes

- `GET /health`
- `GET /api/sports`
- `GET /api/sports/:sport/featured`
- `GET /api/sports/:sport/props`
- `GET /api/sports/:sport/scan` **new**
- `GET /api/nfl/props` legacy compatibility
- `POST /api/slip/validate`
- `POST /api/props/analyze`
- `GET /api/layer5/status`

## Local checks

Scanner tests:

`npm run scanner:test`

Node syntax/integration checks:

`npm run check`

Normative Layer-5 regression suite:

`npm run layer5:test`

## Clean-start Layer-5 designation

No V2 production database was available, so this remains a **fresh V3 clean start**. No historical Layer-5 data was fabricated or migrated.

`LAYER5_PRICING_ENABLED=false` remains the default.

Fresh V3 bootstrap:

`npm run layer5:bootstrap`

Isolated synthetic canary:

`npm run layer5:canary:init`

`npm run layer5:canary`

Read-only production observation after genuine application pricing requests:

`npm run layer5:observe`

Do not globally enable Layer-5 pricing until the genuine application canary is accepted.

## Provider-usage guardrails

Large college slates can contain many events. To avoid automatically spending API quota across every game, live prop scans are bounded by:

- `PROP_EVENT_HORIZON_HOURS=36`
- `PROP_MAX_EVENTS=20`
- `SCAN_ENRICH_LIMIT=12`

If more eligible games exist than the cap, the API response includes an `EVENT_CAP_APPLIED` warning rather than silently pretending the full slate was scanned.

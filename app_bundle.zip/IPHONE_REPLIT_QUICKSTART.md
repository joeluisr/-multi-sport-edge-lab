# iPhone + Replit Quick Start

This release is packaged so Replit only needs to run the app; Replit Agent does not need to rebuild the scanner.

1. Save the release ZIP to the iPhone Files app.
2. Open the Replit project already created for this app.
3. Upload/import the release contents when Replit file operations are available.
4. Add `ODDS_API_KEY` as a Replit secret to enable live props and **Scan Props**.
5. Optional but recommended: add `BALLDONTLIE_API_KEY` to add Last-5/Last-10 statistical evidence to scans.
6. Start the app and choose a sport.
7. Tap **Scan Props**. The app will fetch the live prop board, compare books, and rank the candidates.
8. A scanner result with no qualified props is valid; the app is designed to return PASS instead of forcing a pick.
9. Keep `LAYER5_PRICING_ENABLED=false` while finishing genuine Layer-5 canary validation.

### What the scan labels mean

- `CORE`: strongest combined market + recent-stat evidence.
- `STRONG`: meaningful combined evidence but below Core threshold.
- `HIGH_VARIANCE_VALUE`: supportive data in an inherently volatile market such as HR/TD scorer.
- `MARKET_WATCH`: interesting sportsbook discrepancy, but recent-stat feed is unavailable.
- `WATCH`: some evidence, not enough for a stronger classification.
- `PASS`: insufficient or conflicting evidence.

If Replit still blocks uploads because of account limits, keep the ZIP in Files. The scanner is already built into the package.

/** Sport-agnostic bet-slip validation. */

const DEFAULT_SAME_GAME_MAX = 4;

function normalizeLeg(leg) {
  return {
    ...leg,
    sport: String(leg.sport ?? 'unknown').trim().toLowerCase(),
    playerId: String(leg.playerId ?? '').trim(),
    market: String(leg.market ?? '').trim(),
    gameId: String(leg.gameId ?? '').trim(),
    kickoffTime: leg.kickoffTime ?? null,
  };
}

function legKey(leg) {
  return `${leg.sport}::${leg.playerId}::${leg.market}`;
}

export function validateBetSlip(selectedLegs, now = new Date(), options = {}) {
  const sameGameMax = Number.isInteger(options.sameGameMax) && options.sameGameMax > 0
    ? options.sameGameMax
    : DEFAULT_SAME_GAME_MAX;

  if (!Array.isArray(selectedLegs)) {
    return {
      valid: false,
      errors: [{ code: 'INVALID_SLIP', message: 'Bet slip must be an array.' }],
      activeLegs: [],
      expiredLegs: [],
    };
  }

  const currentTime = new Date(now);
  if (Number.isNaN(currentTime.getTime())) {
    throw new TypeError('Invalid current time supplied to validateBetSlip().');
  }

  const errors = [];
  const expiredLegs = [];
  const candidates = [];

  for (const rawLeg of selectedLegs) {
    const leg = normalizeLeg(rawLeg);
    if (!leg.playerId || !leg.market || !leg.gameId) {
      errors.push({
        code: 'MISSING_FIELDS',
        leg,
        message: 'Each leg requires playerId, market, and gameId.',
      });
      continue;
    }

    const kickoff = new Date(leg.kickoffTime);
    if (!leg.kickoffTime || Number.isNaN(kickoff.getTime())) {
      errors.push({
        code: 'INVALID_KICKOFF',
        leg,
        message: 'Each leg requires a valid kickoffTime.',
      });
      continue;
    }

    if (kickoff <= currentTime) {
      expiredLegs.push({ ...leg, status: 'Expired' });
      continue;
    }
    candidates.push({ ...leg, status: 'Active' });
  }

  const seen = new Set();
  const deduped = [];
  for (const leg of candidates) {
    const key = legKey(leg);
    if (seen.has(key)) {
      errors.push({
        code: 'DUPLICATE_PLAYER_MARKET',
        leg,
        message: 'You cannot select multiple lines for the same player market.',
      });
      continue;
    }
    seen.add(key);
    deduped.push(leg);
  }

  const gameCounts = new Map();
  const activeLegs = [];
  for (const leg of deduped) {
    const gameKey = `${leg.sport}::${leg.gameId}`;
    const count = gameCounts.get(gameKey) ?? 0;
    if (count >= sameGameMax) {
      errors.push({
        code: 'SAME_GAME_MAX_EXCEEDED',
        leg,
        message: `Maximum ${sameGameMax} player prop legs are allowed from the same game.`,
      });
      continue;
    }
    gameCounts.set(gameKey, count + 1);
    activeLegs.push(leg);
  }

  return {
    valid: errors.length === 0,
    errors,
    activeLegs,
    expiredLegs,
    meta: {
      sameGameMax,
      activeGameCounts: Object.fromEntries(gameCounts),
      sports: [...new Set(activeLegs.map((leg) => leg.sport))],
      checkedAt: currentTime.toISOString(),
    },
  };
}

export function validateNewSelection(existingLegs, newLeg, now = new Date(), options = {}) {
  const result = validateBetSlip([...existingLegs, newLeg], now, options);
  const normalized = normalizeLeg(newLeg);
  return {
    ...result,
    accepted: result.errors.length === 0 && result.activeLegs.some(
      (leg) => (leg.id && normalized.id && leg.id === normalized.id) || legKey(leg) === legKey(normalized),
    ),
  };
}

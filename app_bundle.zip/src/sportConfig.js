export const SPORT_CONFIG = Object.freeze({
  nfl: {
    slug: 'nfl',
    title: 'NFL',
    group: 'Football',
    providerKey: 'americanfootball_nfl',
    leagueSize: 32,
    propMarkets: [
      'player_pass_yds',
      'player_pass_completions',
      'player_rush_yds',
      'player_rush_attempts',
      'player_receptions',
      'player_reception_yds',
      'player_anytime_td',
    ],
  },
  cfb: {
    slug: 'cfb',
    title: 'CFB',
    group: 'Football',
    providerKey: 'americanfootball_ncaaf',
    leagueSize: 134,
    propMarkets: [
      'player_pass_yds',
      'player_pass_completions',
      'player_rush_yds',
      'player_rush_attempts',
      'player_receptions',
      'player_reception_yds',
      'player_anytime_td',
    ],
  },
  mlb: {
    slug: 'mlb',
    title: 'MLB',
    group: 'Baseball',
    providerKey: 'baseball_mlb',
    leagueSize: 30,
    propMarkets: [
      'batter_singles',
      'batter_hits',
      'batter_total_bases',
      'batter_hits_runs_rbis',
      'batter_home_runs',
      'pitcher_strikeouts',
      'pitcher_hits_allowed',
      'pitcher_outs',
    ],
  },
  nba: {
    slug: 'nba',
    title: 'NBA',
    group: 'Basketball',
    providerKey: 'basketball_nba',
    leagueSize: 30,
    propMarkets: [
      'player_points',
      'player_rebounds',
      'player_assists',
      'player_threes',
      'player_points_rebounds_assists',
      'player_rebounds_assists',
    ],
  },
  wnba: {
    slug: 'wnba',
    title: 'WNBA',
    group: 'Basketball',
    providerKey: 'basketball_wnba',
    leagueSize: 15,
    propMarkets: [
      'player_points',
      'player_rebounds',
      'player_assists',
      'player_threes',
      'player_points_rebounds_assists',
      'player_rebounds_assists',
    ],
  },
  ncaab: {
    slug: 'ncaab',
    title: 'NCAAB',
    group: 'Basketball',
    providerKey: 'basketball_ncaab',
    leagueSize: 365,
    propMarkets: [
      'player_points',
      'player_rebounds',
      'player_assists',
      'player_threes',
      'player_points_rebounds_assists',
    ],
  },
  nhl: {
    slug: 'nhl',
    title: 'NHL',
    group: 'Hockey',
    providerKey: 'icehockey_nhl',
    leagueSize: 32,
    propMarkets: [
      'player_shots_on_goal',
      'player_total_saves',
      'player_points',
      'player_assists',
      'player_goal_scorer_anytime',
    ],
  },
});

export const FEATURED_MARKETS = Object.freeze(['h2h', 'spreads', 'totals']);

export function getSportConfig(slug) {
  return SPORT_CONFIG[String(slug ?? '').toLowerCase()] ?? null;
}

export function listSports() {
  return Object.values(SPORT_CONFIG).map(({ propMarkets, ...sport }) => ({
    ...sport,
    propMarketCount: propMarkets.length,
  }));
}

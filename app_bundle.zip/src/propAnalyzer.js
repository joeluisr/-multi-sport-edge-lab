/**
 * Transparent multi-sport directional prop analyzer.
 * It intentionally returns a directional score, not a calibrated probability.
 */

function avg(values) {
  const clean = values.filter(Number.isFinite);
  return clean.length ? clean.reduce((a, b) => a + b, 0) / clean.length : null;
}

function slope(values) {
  const clean = values.filter(Number.isFinite);
  if (clean.length < 2) return 0;
  const n = clean.length;
  const xMean = (n - 1) / 2;
  const yMean = avg(clean);
  let numerator = 0;
  let denominator = 0;
  clean.forEach((y, x) => {
    numerator += (x - xMean) * (y - yMean);
    denominator += (x - xMean) ** 2;
  });
  return denominator ? numerator / denominator : 0;
}

function defenseScore(rank, leagueSize, mode) {
  if (!Number.isFinite(rank) || rank < 1 || rank > leagueSize) return 0;
  const percentile = (rank - 1) / Math.max(1, leagueSize - 1);
  return mode === '1_is_easiest' ? (0.5 - percentile) * 2 : (percentile - 0.5) * 2;
}

function inferRecentStat(game, market) {
  const candidates = [
    game.stat,
    game.value,
    game[market],
    game.yards,
    game.points,
    game.rebounds,
    game.assists,
    game.hits,
    game.totalBases,
    game.strikeouts,
  ];
  const value = candidates.map(Number).find(Number.isFinite);
  return value ?? NaN;
}

function scriptScore({ sport, market, teamSpread, gameTotal }) {
  const favorite = teamSpread < 0;
  const underdog = teamSpread > 0;
  const magnitude = Math.min(0.7, Math.abs(teamSpread) / 14);
  let score = 0;

  if (sport === 'nfl' || sport === 'cfb') {
    if (market.includes('rush')) score += favorite ? magnitude : -magnitude;
    if (market.includes('pass') || market.includes('reception')) score += underdog ? magnitude : (favorite && Math.abs(teamSpread) >= 7 ? -0.35 : 0);
    if (market.includes('td')) score += favorite ? 0.25 : 0;
    if (gameTotal >= 47 && !market.includes('rush')) score += 0.15;
    if (gameTotal <= 41) score -= 0.15;
  } else if (sport === 'nba' || sport === 'wnba' || sport === 'ncaab') {
    if (Math.abs(teamSpread) >= 10) score -= 0.25;
    if (gameTotal >= 225 && sport === 'nba') score += 0.2;
    if (gameTotal >= 165 && sport === 'wnba') score += 0.15;
  } else if (sport === 'mlb') {
    if (market.startsWith('batter_') && gameTotal >= 9) score += 0.2;
    if (market.startsWith('pitcher_') && gameTotal >= 9) score -= 0.15;
    if (market === 'pitcher_outs' && Math.abs(teamSpread) >= 1.5) score -= 0.1;
  }
  return score;
}

export function analyzePlayerProp(input) {
  const {
    sport = 'nfl',
    playerName,
    market,
    line,
    last5 = [],
    defenseRankVsPosition,
    defenseRankMode = '1_is_toughest',
    leagueSize = 32,
    playerTeamSpread = 0,
    gameTotal = 0,
  } = input;

  if (!playerName || !market || !Number.isFinite(line)) {
    throw new TypeError('playerName, market, and numeric line are required.');
  }

  const recentStats = last5.map((game) => inferRecentStat(game, market));
  const avgStat = avg(recentStats);
  const recentTrend = slope(recentStats);
  const minutesOrSnaps = last5.map((game) => Number(game.minutes ?? game.snapPct));
  const avgRole = avg(minutesOrSnaps);
  const usage = last5.map((game) => Number(game.usagePct ?? game.targets ?? game.plateAppearances ?? game.pitchCount));
  const avgUsage = avg(usage);
  const usageTrend = slope(usage);

  let volume = 0;
  if (avgStat != null) volume += Math.max(-1.5, Math.min(1.5, (avgStat - line) / Math.max(1, Math.abs(line) * 0.15)));
  const trendThreshold = Math.max(0.25, Math.abs(line) * 0.04);
  if (recentTrend > trendThreshold) volume += 0.3;
  if (recentTrend < -trendThreshold) volume -= 0.3;
  if (usageTrend > 0.5) volume += 0.2;
  if (usageTrend < -0.5) volume -= 0.2;

  const matchup = defenseScore(Number(defenseRankVsPosition), Number(leagueSize), defenseRankMode);
  const script = scriptScore({ sport, market, teamSpread: Number(playerTeamSpread), gameTotal: Number(gameTotal) });
  const score = volume + matchup + script;
  const recommendation = score >= 0.75 ? 'Over' : score <= -0.75 ? 'Under' : 'Pass';

  return {
    sport,
    playerName,
    market,
    line,
    recommendation,
    directionalScore: Number(score.toFixed(2)),
    sections: {
      RecentFormAndRole: {
        score: Number(volume.toFixed(2)),
        avgLast5: avgStat == null ? null : Number(avgStat.toFixed(2)),
        trendPerGame: Number(recentTrend.toFixed(2)),
        avgRole: avgRole == null ? null : Number(avgRole.toFixed(2)),
        avgUsage: avgUsage == null ? null : Number(avgUsage.toFixed(2)),
      },
      Matchup: {
        score: Number(matchup.toFixed(2)),
        defenseRankVsPosition: Number.isFinite(Number(defenseRankVsPosition)) ? Number(defenseRankVsPosition) : null,
        defenseRankMode,
        leagueSize,
      },
      GameScript: {
        score: Number(script.toFixed(2)),
        playerTeamSpread,
        gameTotal,
      },
    },
    warning: 'Directional heuristic only. Do not treat this score as a calibrated win probability without a fitted and backtested model.',
  };
}

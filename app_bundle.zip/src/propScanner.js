import { americanToImplied, devigTwoWay, mean, median, round } from './marketMath.js';

const VOLATILE_MARKETS = new Set([
  'player_anytime_td',
  'batter_home_runs',
  'player_goal_scorer_anytime',
]);

function marketLabel(key) {
  return String(key || '').replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function freshnessMinutes(timestamp, nowMs) {
  const parsed = Date.parse(timestamp || '');
  return Number.isFinite(parsed) ? Math.max(0, (nowMs - parsed) / 60000) : null;
}

function collectGroups(board) {
  const groups = new Map();
  for (const game of board.games ?? []) {
    for (const [market, players] of Object.entries(game.markets ?? {})) {
      for (const [playerName, player] of Object.entries(players ?? {})) {
        const key = `${game.gameId}|${market}|${playerName.toLowerCase()}`;
        const entry = groups.get(key) ?? {
          key,
          gameId: game.gameId,
          commenceTime: game.commenceTime,
          homeTeam: game.homeTeam,
          awayTeam: game.awayTeam,
          matchup: game.matchup,
          market,
          playerName,
          offers: [],
        };
        for (const [bookKey, book] of Object.entries(player.books ?? {})) {
          for (const offer of book.offers ?? []) {
            entry.offers.push({
              bookKey,
              bookmaker: book.bookmaker,
              lastUpdate: book.lastUpdate,
              line: Number.isFinite(Number(offer.line)) ? Number(offer.line) : null,
              overOdds: Number(offer.outcomes?.over?.americanOdds),
              underOdds: Number(offer.outcomes?.under?.americanOdds),
            });
          }
        }
        groups.set(key, entry);
      }
    }
  }
  return [...groups.values()].filter((group) => group.offers.some((offer) => Number.isFinite(offer.line)));
}

function bestPrice(offers, side) {
  const field = side === 'over' ? 'overOdds' : 'underOdds';
  const valid = offers.filter((offer) => Number.isFinite(offer[field]));
  if (!valid.length) return null;
  return valid.reduce((best, offer) => Number(offer[field]) > Number(best[field]) ? offer : best);
}

function marketEvidence(group, side, nowMs) {
  const lines = group.offers.map((offer) => offer.line).filter(Number.isFinite);
  const consensusLine = median(lines);
  if (!Number.isFinite(consensusLine)) return null;
  const targetLine = side === 'over' ? Math.min(...lines) : Math.max(...lines);
  const targetOffers = group.offers.filter((offer) => offer.line === targetLine);
  const best = bestPrice(targetOffers, side);
  if (!best) return null;

  const paired = targetOffers
    .map((offer) => devigTwoWay(offer.overOdds, offer.underOdds))
    .filter(Boolean);
  const fairProbability = mean(paired.map((pair) => pair[side]));
  const sideField = side === 'over' ? 'overOdds' : 'underOdds';
  const targetSideImplied = targetOffers.map((offer) => americanToImplied(offer[sideField])).filter(Number.isFinite);
  const bestImplied = americanToImplied(best[sideField]);
  const averageImplied = mean(targetSideImplied);
  const priceAdvantagePctPoints = Number.isFinite(bestImplied) && Number.isFinite(averageImplied)
    ? Math.max(0, (averageImplied - bestImplied) * 100)
    : 0;
  const uniqueBooks = new Set(group.offers.map((offer) => offer.bookKey)).size;
  const targetBookCount = new Set(targetOffers.map((offer) => offer.bookKey)).size;
  const lineAdvantage = side === 'over' ? consensusLine - targetLine : targetLine - consensusLine;
  const ages = group.offers.map((offer) => freshnessMinutes(offer.lastUpdate, nowMs)).filter(Number.isFinite);
  const medianAgeMinutes = median(ages);

  let score = 0;
  if (fairProbability >= 0.56) score += 1.25;
  else if (fairProbability >= 0.53) score += 0.75;
  else if (fairProbability >= 0.51) score += 0.25;
  score += Math.min(1.5, Math.max(0, lineAdvantage) * 0.7);
  if (uniqueBooks >= 4) score += 0.6;
  else if (uniqueBooks >= 3) score += 0.45;
  else if (uniqueBooks >= 2) score += 0.2;
  else score -= 0.5;
  if (priceAdvantagePctPoints >= 2) score += 0.5;
  else if (priceAdvantagePctPoints >= 1) score += 0.25;
  if (Number.isFinite(medianAgeMinutes) && medianAgeMinutes <= 30) score += 0.25;
  if (Number.isFinite(medianAgeMinutes) && medianAgeMinutes > 180) score -= 0.25;

  const why = [];
  const risks = [];
  if (lineAdvantage >= 0.5) why.push(`${best.bookmaker} offers a ${round(lineAdvantage, 2)}-unit better line than the board median.`);
  if (fairProbability >= 0.53) why.push(`Paired no-vig prices at the target line lean ${side} (${round(fairProbability * 100, 1)}%).`);
  if (priceAdvantagePctPoints >= 1) why.push(`Best price is about ${round(priceAdvantagePctPoints, 1)} implied-probability points cheaper than same-line peers.`);
  if (uniqueBooks >= 3) why.push(`${uniqueBooks} books provide market coverage.`);
  if (uniqueBooks < 2) risks.push('Single-book market: weak consensus evidence.');
  if (!paired.length) risks.push('No paired over/under price at the target line, so no-vig support is unavailable.');
  if (Number.isFinite(medianAgeMinutes) && medianAgeMinutes > 120) risks.push('Some market data may be stale.');
  if (lineAdvantage < 0.5) risks.push('No meaningful line-shopping advantage versus the board median.');

  return {
    side,
    targetLine,
    consensusLine: round(consensusLine, 2),
    lineAdvantage: round(lineAdvantage, 2),
    bestBook: best.bookmaker,
    bestBookKey: best.bookKey,
    bestAmericanOdds: Number(best[sideField]),
    fairProbability: round(fairProbability, 4),
    priceAdvantagePctPoints: round(priceAdvantagePctPoints, 2),
    bookCount: uniqueBooks,
    targetBookCount,
    medianAgeMinutes: round(medianAgeMinutes, 1),
    score: round(score, 2),
    why,
    risks,
  };
}

function statSummary(logs, side, line) {
  const values = (logs ?? []).map((row) => Number(row.value)).filter(Number.isFinite);
  const hit = (value) => side === 'over' ? value > line : value < line;
  const pushes = values.filter((value) => value === line).length;
  const hits = values.filter(hit).length;
  return {
    sample: values.length,
    hits,
    pushes,
    hitRate: values.length ? hits / values.length : null,
    pushRate: values.length ? pushes / values.length : null,
    average: mean(values),
    median: median(values),
    values,
  };
}

function statsEvidence(enrichment, side, line) {
  if (!enrichment || enrichment.status !== 'ok') {
    return {
      available: false,
      score: 0,
      source: enrichment?.source ?? null,
      warning: enrichment?.warning ?? 'Recent player game logs were not available.',
      why: [],
      risks: ['Statistical enrichment unavailable; candidate cannot be promoted above market-watch status.'],
    };
  }

  const last10 = (enrichment.last10 ?? []).slice(0, 10);
  const last5 = last10.slice(0, 5);
  const last5Summary = statSummary(last5, side, line);
  const last10Summary = statSummary(last10, side, line);
  const opponentSummary = statSummary(enrichment.vsOpponent ?? [], side, line);
  const avg5 = last5Summary.average;
  const avg10 = last10Summary.average;
  const projection = Number.isFinite(avg5) && Number.isFinite(avg10) ? (0.6 * avg5 + 0.4 * avg10) : (avg5 ?? avg10);
  const signedProjectionEdge = Number.isFinite(projection)
    ? (side === 'over' ? projection - line : line - projection)
    : null;
  const projectionEdgePct = Number.isFinite(signedProjectionEdge) ? signedProjectionEdge / Math.max(1, Math.abs(line)) : null;

  let score = 0;
  const why = [];
  const risks = [];
  if (last5Summary.sample >= 3) {
    if (last5Summary.hitRate >= 0.8) score += 1.5;
    else if (last5Summary.hitRate >= 0.6) score += 0.75;
    else if (last5Summary.hitRate != null && last5Summary.hitRate <= 0.4) score -= 0.5;
  }
  if (last10Summary.sample >= 5) {
    if (last10Summary.hitRate >= 0.7) score += 1.5;
    else if (last10Summary.hitRate >= 0.6) score += 0.75;
    else if (last10Summary.hitRate != null && last10Summary.hitRate <= 0.4) score -= 0.75;
    if (projectionEdgePct >= 0.10) score += 1.25;
    else if (projectionEdgePct >= 0.05) score += 0.75;
    else if (projectionEdgePct >= 0.02) score += 0.25;
    else if (projectionEdgePct != null && projectionEdgePct <= -0.05) score -= 1;
  }
  if (opponentSummary.sample >= 3 && opponentSummary.hitRate >= 0.67) score += 0.5;
  if (opponentSummary.sample >= 3 && opponentSummary.hitRate <= 0.33) score -= 0.5;

  if (last5Summary.hitRate != null) why.push(`Last 5 hit rate at this exact line: ${Math.round(last5Summary.hitRate * 100)}%.`);
  if (last10Summary.hitRate != null) why.push(`Last 10 hit rate at this exact line: ${Math.round(last10Summary.hitRate * 100)}%.`);
  if (Number.isFinite(projection)) why.push(`0.6×L5 + 0.4×L10 recent-form projection: ${round(projection, 2)}.`);
  if (opponentSummary.sample >= 2) why.push(`Vs current opponent sample: ${opponentSummary.sample} games, ${Math.round((opponentSummary.hitRate ?? 0) * 100)}% hit rate.`);
  if (last10Summary.sample < 5) risks.push('Fewer than five recent game logs were available.');
  if (last5Summary.hitRate != null && last10Summary.hitRate != null && Math.abs(last5Summary.hitRate - last10Summary.hitRate) >= 0.4) risks.push('Short-term and 10-game hit rates disagree sharply.');
  if (projectionEdgePct != null && projectionEdgePct < 0) risks.push('Recent-form projection is on the wrong side of the current line.');

  return {
    available: true,
    source: enrichment.source,
    player: enrichment.player,
    team: enrichment.team,
    opponent: enrichment.opponent,
    score: round(score, 2),
    projection: round(projection, 2),
    projectionEdgePct: round(projectionEdgePct == null ? null : projectionEdgePct * 100, 2),
    last5: {
      sample: last5Summary.sample,
      hitRate: round(last5Summary.hitRate, 3),
      average: round(last5Summary.average, 2),
      pushRate: round(last5Summary.pushRate, 3),
      values: last5Summary.values,
    },
    last10: {
      sample: last10Summary.sample,
      hitRate: round(last10Summary.hitRate, 3),
      average: round(last10Summary.average, 2),
      pushRate: round(last10Summary.pushRate, 3),
      values: last10Summary.values,
    },
    vsOpponent: {
      sample: opponentSummary.sample,
      hitRate: round(opponentSummary.hitRate, 3),
      average: round(opponentSummary.average, 2),
      pushRate: round(opponentSummary.pushRate, 3),
      values: opponentSummary.values,
    },
    logs: last10,
    why,
    risks,
  };
}

function classify({ totalScore, statsAvailable, volatile }) {
  if (!statsAvailable) return totalScore >= 2.5 ? 'MARKET_WATCH' : 'PASS';
  if (volatile) return totalScore >= 4 ? 'HIGH_VARIANCE_VALUE' : totalScore >= 2.5 ? 'WATCH' : 'PASS';
  if (totalScore >= 4.5) return 'CORE';
  if (totalScore >= 3.25) return 'STRONG';
  if (totalScore >= 2) return 'WATCH';
  return 'PASS';
}

function classificationRank(value) {
  return ({ CORE: 6, STRONG: 5, HIGH_VARIANCE_VALUE: 4, MARKET_WATCH: 3, WATCH: 2, PASS: 1 })[value] ?? 0;
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  async function runner() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await worker(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(Math.max(1, limit), Math.max(1, items.length)) }, runner));
  return results;
}

export async function scanPropBoard({ sportConfig, board, enrichPlayer = null, maxEnrichment = 12, enrichConcurrency = 4, now = new Date() }) {
  const groups = collectGroups(board);
  const nowMs = now instanceof Date ? now.getTime() : new Date(now).getTime();
  const preliminary = [];
  for (const group of groups) {
    for (const side of ['over', 'under']) {
      const market = marketEvidence(group, side, nowMs);
      if (!market) continue;
      preliminary.push({ group, market, preliminaryScore: market.score });
    }
  }
  preliminary.sort((a, b) => b.preliminaryScore - a.preliminaryScore);

  const targetGroups = [];
  const seenTargets = new Set();
  for (const item of preliminary) {
    if (targetGroups.length >= Math.max(0, maxEnrichment)) break;
    if (seenTargets.has(item.group.key)) continue;
    seenTargets.add(item.group.key);
    targetGroups.push(item.group);
  }
  const enrichmentCache = new Map();
  if (enrichPlayer && targetGroups.length) {
    await mapLimit(targetGroups, enrichConcurrency, async (group) => {
      const enrichment = await enrichPlayer({
        sport: sportConfig.slug,
        playerName: group.playerName,
        market: group.market,
        homeTeam: group.homeTeam,
        awayTeam: group.awayTeam,
        commenceTime: group.commenceTime,
      });
      enrichmentCache.set(group.key, enrichment);
    });
  }
  const candidates = [];

  for (const item of preliminary) {
    const { group, market } = item;
    const enrichment = enrichmentCache.get(group.key) ?? null;
    const stats = statsEvidence(enrichment, market.side, market.targetLine);
    const totalScore = round(market.score + stats.score, 2);
    const volatile = VOLATILE_MARKETS.has(group.market);
    const qualifiedStats = stats.available && Number(stats.last10?.sample || 0) >= 5;
    const classification = classify({ totalScore, statsAvailable: qualifiedStats, volatile });
    const reasons = [...market.why, ...stats.why];
    const risks = [...market.risks, ...stats.risks];
    if (volatile) risks.push('This market is inherently high variance and is never promoted to CORE.');
    candidates.push({
      sport: sportConfig.slug,
      gameId: group.gameId,
      matchup: group.matchup,
      commenceTime: group.commenceTime,
      playerName: group.playerName,
      market: group.market,
      marketLabel: marketLabel(group.market),
      side: market.side,
      line: market.targetLine,
      classification,
      evidenceScore: totalScore,
      marketEvidence: market,
      statsEvidence: stats,
      reasons,
      risks,
      dataQuality: stats.available
        ? (stats.last10.sample >= 8 && market.bookCount >= 3 ? 'HIGH' : stats.last10.sample >= 5 ? 'MEDIUM' : 'LIMITED')
        : (market.bookCount >= 3 ? 'MARKET_ONLY' : 'LOW'),
      warning: 'Evidence score is a transparent ranking heuristic, not a calibrated win probability.',
    });
  }

  candidates.sort((a, b) => {
    const classDiff = classificationRank(b.classification) - classificationRank(a.classification);
    return classDiff || b.evidenceScore - a.evidenceScore;
  });

  const nonPass = candidates.filter((candidate) => candidate.classification !== 'PASS');
  return {
    sport: sportConfig.slug,
    generatedAt: new Date(nowMs).toISOString(),
    dataMode: enrichPlayer ? 'market-plus-optional-stats' : 'market-only',
    scannedPlayerMarkets: groups.length,
    scannedSides: candidates.length,
    actionableCount: nonPass.length,
    summary: {
      core: candidates.filter((candidate) => candidate.classification === 'CORE').length,
      strong: candidates.filter((candidate) => candidate.classification === 'STRONG').length,
      highVariance: candidates.filter((candidate) => candidate.classification === 'HIGH_VARIANCE_VALUE').length,
      marketWatch: candidates.filter((candidate) => candidate.classification === 'MARKET_WATCH').length,
      watch: candidates.filter((candidate) => candidate.classification === 'WATCH').length,
      pass: candidates.filter((candidate) => candidate.classification === 'PASS').length,
    },
    candidates,
  };
}

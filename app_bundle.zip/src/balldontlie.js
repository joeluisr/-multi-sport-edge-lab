const BASE = process.env.BALLDONTLIE_API_BASE?.trim() || 'https://api.balldontlie.io';
const CACHE_TTL_MS = 15 * 60 * 1000;
const cache = new Map();

const ENDPOINTS = Object.freeze({
  nfl: { player: '/nfl/v1/players', stats: '/nfl/v1/stats' },
  cfb: { player: '/ncaaf/v1/players', stats: '/ncaaf/v1/player_stats' },
  mlb: { player: '/mlb/v1/players', stats: '/mlb/v1/stats' },
  nba: { player: '/v1/players', stats: '/v1/stats' },
  wnba: { player: '/wnba/v1/players', stats: '/wnba/v1/player_stats' },
  ncaab: { player: '/ncaab/v1/players', stats: '/ncaab/v1/player_stats' },
});

function getApiKey() {
  return process.env.BALLDONTLIE_API_KEY?.trim() || null;
}

function normalizeName(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b(jr|sr|ii|iii|iv)\b/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function fullPlayerName(player) {
  return player?.full_name || [player?.first_name, player?.last_name].filter(Boolean).join(' ').trim();
}

function teamName(team) {
  return team?.full_name || team?.display_name || [team?.location, team?.name].filter(Boolean).join(' ').trim() || team?.college || team?.abbreviation || null;
}

async function cachedJson(path, params) {
  const apiKey = getApiKey();
  if (!apiKey) throw Object.assign(new Error('BALLDONTLIE_API_KEY is not configured.'), { code: 'BDL_NOT_CONFIGURED' });
  const url = new URL(`${BASE}${path}`);
  for (const [key, value] of Object.entries(params ?? {})) {
    if (value == null) continue;
    if (Array.isArray(value)) value.forEach((item) => url.searchParams.append(key, String(item)));
    else url.searchParams.set(key, String(value));
  }
  const cacheKey = url.toString();
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;
  const response = await fetch(url, {
    headers: { Authorization: apiKey, Accept: 'application/json' },
    signal: AbortSignal.timeout(12_000),
  });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : null; } catch { data = raw; }
  if (!response.ok) {
    throw Object.assign(new Error(`BALLDONTLIE request failed with HTTP ${response.status}.`), {
      code: 'BDL_REQUEST_FAILED',
      providerStatus: response.status,
      providerBody: data,
    });
  }
  cache.set(cacheKey, { at: Date.now(), data });
  return data;
}

function seasonForSport(sport, when = new Date()) {
  const date = when instanceof Date ? when : new Date(when);
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth() + 1;
  if (sport === 'nba' || sport === 'ncaab') return month >= 9 ? year : year - 1;
  return year;
}

function selectPlayer(rows, requestedName) {
  const target = normalizeName(requestedName);
  if (!target) return null;
  const exact = rows.find((player) => normalizeName(fullPlayerName(player)) === target);
  if (exact) return exact;
  const tokens = new Set(target.split(' '));
  const scored = rows.map((player) => {
    const name = normalizeName(fullPlayerName(player));
    const playerTokens = new Set(name.split(' '));
    let shared = 0;
    tokens.forEach((token) => { if (playerTokens.has(token)) shared += 1; });
    return { player, score: shared / Math.max(tokens.size, playerTokens.size, 1) };
  }).sort((a, b) => b.score - a.score);
  return scored[0]?.score >= 0.67 ? scored[0].player : null;
}

function number(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function mlbOutsFromIp(value) {
  if (value == null) return null;
  const text = String(value);
  if (!text.includes('.')) return Number.isFinite(Number(text)) ? Number(text) * 3 : null;
  const [wholeRaw, fracRaw] = text.split('.');
  const whole = Number(wholeRaw);
  const frac = Number(fracRaw);
  if (!Number.isFinite(whole) || !Number.isFinite(frac) || frac < 0 || frac > 2) return null;
  return whole * 3 + frac;
}

function marketValue(sport, market, row) {
  if (sport === 'nfl' || sport === 'cfb') {
    const map = {
      player_pass_yds: 'passing_yards',
      player_pass_completions: 'passing_completions',
      player_rush_yds: 'rushing_yards',
      player_rush_attempts: 'rushing_attempts',
      player_receptions: 'receptions',
      player_reception_yds: 'receiving_yards',
    };
    if (map[market]) return number(row[map[market]]);
    if (market === 'player_anytime_td') {
      const rush = number(row.rushing_touchdowns) ?? 0;
      const receive = number(row.receiving_touchdowns) ?? 0;
      const returns = number(row.kick_return_touchdowns) ?? 0;
      const punts = number(row.punt_return_touchdowns) ?? 0;
      return rush + receive + returns + punts;
    }
  }
  if (sport === 'nba' || sport === 'wnba' || sport === 'ncaab') {
    const pts = number(row.pts ?? row.points);
    const reb = number(row.reb ?? row.rebounds);
    const ast = number(row.ast ?? row.assists);
    if (market === 'player_points') return pts;
    if (market === 'player_rebounds') return reb;
    if (market === 'player_assists') return ast;
    if (market === 'player_threes') return number(row.fg3m ?? row.threes_made);
    if (market === 'player_points_rebounds_assists' && [pts, reb, ast].every(Number.isFinite)) return pts + reb + ast;
    if (market === 'player_rebounds_assists' && [reb, ast].every(Number.isFinite)) return reb + ast;
  }
  if (sport === 'mlb') {
    const hits = number(row.hits);
    const doubles = number(row.doubles) ?? 0;
    const triples = number(row.triples) ?? 0;
    const homeRuns = number(row.home_runs) ?? 0;
    const runs = number(row.runs) ?? 0;
    const rbis = number(row.rbis ?? row.rbi) ?? 0;
    if (market === 'batter_hits') return hits;
    if (market === 'batter_singles' && Number.isFinite(hits)) return hits - doubles - triples - homeRuns;
    if (market === 'batter_total_bases' && Number.isFinite(hits)) return (hits - doubles - triples - homeRuns) + 2 * doubles + 3 * triples + 4 * homeRuns;
    if (market === 'batter_hits_runs_rbis' && Number.isFinite(hits)) return hits + runs + rbis;
    if (market === 'batter_home_runs') return homeRuns;
    if (market === 'pitcher_strikeouts') return number(row.p_strikeouts ?? row.pitcher_strikeouts ?? row.strikeouts);
    if (market === 'pitcher_hits_allowed') return number(row.p_hits ?? row.pitcher_hits_allowed);
    if (market === 'pitcher_outs') return mlbOutsFromIp(row.ip ?? row.innings_pitched);
  }
  return null;
}

function rowDate(row) {
  return row?.game?.date || row?.game?.datetime || row?.game?.start_time || row?.date || null;
}

function sameTeam(team, candidate) {
  if (!team || !candidate) return false;
  if (team.id != null && candidate.id != null && String(team.id) === String(candidate.id)) return true;
  const a = normalizeName(teamName(team));
  const b = normalizeName(teamName(candidate));
  return Boolean(a && b && (a === b || a.includes(b) || b.includes(a)));
}

function opponentFromRow(row, playerTeam) {
  const game = row?.game;
  if (!game || !playerTeam) return null;
  const home = game.home_team || game.homeTeam || game.home;
  const away = game.visitor_team || game.away_team || game.awayTeam || game.visitor || game.away;
  if (sameTeam(playerTeam, home)) return teamName(away);
  if (sameTeam(playerTeam, away)) return teamName(home);
  return null;
}

function currentOpponent({ homeTeam, awayTeam }, playerTeam) {
  const current = normalizeName(teamName(playerTeam));
  const home = normalizeName(homeTeam);
  const away = normalizeName(awayTeam);
  if (!current) return null;
  if (home && (current.includes(home) || home.includes(current))) return awayTeam;
  if (away && (current.includes(away) || away.includes(current))) return homeTeam;
  return null;
}

export function isBalldontlieConfigured() {
  return Boolean(getApiKey());
}

export function balldontlieSupportedSports() {
  return Object.keys(ENDPOINTS);
}

export async function enrichPropWithBalldontlie(context) {
  const { sport, playerName, market, commenceTime } = context;
  const endpoints = ENDPOINTS[sport];
  if (!endpoints) return { status: 'unsupported', source: 'BALLDONTLIE', warning: `BALLDONTLIE recent-game enrichment is not enabled for ${sport.toUpperCase()} in this build.` };
  if (!getApiKey()) return { status: 'not_configured', source: 'BALLDONTLIE', warning: 'BALLDONTLIE_API_KEY is not configured.' };

  try {
    const playerPayload = await cachedJson(endpoints.player, { search: playerName, per_page: 25 });
    const player = selectPlayer(playerPayload?.data ?? [], playerName);
    if (!player) return { status: 'not_found', source: 'BALLDONTLIE', warning: `Could not resolve ${playerName} in the stats feed.` };

    const season = seasonForSport(sport, commenceTime ? new Date(commenceTime) : new Date());
    const statsPayload = await cachedJson(endpoints.stats, {
      'player_ids[]': [player.id],
      'seasons[]': [season],
      per_page: 100,
    });
    const rows = (statsPayload?.data ?? [])
      .map((row) => ({ row, value: marketValue(sport, market, row), date: rowDate(row) }))
      .filter((entry) => Number.isFinite(entry.value) && entry.date)
      .sort((a, b) => Date.parse(b.date) - Date.parse(a.date));

    const team = player.team || rows[0]?.row?.team || null;
    const opponent = currentOpponent(context, team);
    const last10 = rows.slice(0, 10).map((entry) => ({
      date: entry.date,
      value: entry.value,
      opponent: opponentFromRow(entry.row, team),
    }));
    const opponentNorm = normalizeName(opponent);
    const vsOpponent = opponentNorm
      ? rows.filter((entry) => normalizeName(opponentFromRow(entry.row, team)) === opponentNorm).slice(0, 10).map((entry) => ({ date: entry.date, value: entry.value, opponent }))
      : [];

    if (!last10.length) return { status: 'no_logs', source: 'BALLDONTLIE', player: fullPlayerName(player), team: teamName(team), opponent, warning: 'Player resolved, but no compatible current-season game logs were returned for this prop market.' };
    return {
      status: 'ok',
      source: 'BALLDONTLIE',
      player: fullPlayerName(player),
      team: teamName(team),
      opponent,
      season,
      last10,
      vsOpponent,
    };
  } catch (error) {
    return { status: 'error', source: 'BALLDONTLIE', warning: error.message, code: error.code || 'BDL_ENRICHMENT_ERROR' };
  }
}

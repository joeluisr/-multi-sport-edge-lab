export function americanToImplied(odds) {
  const value = Number(odds);
  if (!Number.isFinite(value) || value === 0) return null;
  return value > 0 ? 100 / (value + 100) : (-value) / ((-value) + 100);
}

export function devigTwoWay(overOdds, underOdds) {
  const overRaw = americanToImplied(overOdds);
  const underRaw = americanToImplied(underOdds);
  if (!Number.isFinite(overRaw) || !Number.isFinite(underRaw)) return null;
  const total = overRaw + underRaw;
  if (!(total > 0)) return null;
  return { over: overRaw / total, under: underRaw / total, hold: total - 1 };
}

export function mean(values) {
  const clean = values.map(Number).filter(Number.isFinite);
  return clean.length ? clean.reduce((sum, value) => sum + value, 0) / clean.length : null;
}

export function median(values) {
  const clean = values.map(Number).filter(Number.isFinite).sort((a, b) => a - b);
  if (!clean.length) return null;
  const middle = Math.floor(clean.length / 2);
  return clean.length % 2 ? clean[middle] : (clean[middle - 1] + clean[middle]) / 2;
}

export function round(value, digits = 3) {
  if (!Number.isFinite(Number(value))) return null;
  const scale = 10 ** digits;
  return Math.round(Number(value) * scale) / scale;
}

export function betterAmericanPrice(a, b) {
  if (!Number.isFinite(Number(a))) return b;
  if (!Number.isFinite(Number(b))) return a;
  return Number(a) >= Number(b) ? a : b;
}

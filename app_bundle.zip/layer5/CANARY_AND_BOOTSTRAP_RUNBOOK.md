# Layer-5 Fresh V3 Bootstrap & Canary Runbook

## Status proved in this workspace

- Normative Python Layer-5 parity suite: **18/18 executed fixtures pass**.
- Fresh file-backed V3 bootstrap: **PASS**.
- SQLite policy after bootstrap: `foreign_keys=1`, `busy_timeout=5000`, `journal_mode=wal`.
- Schema structural checks: required 5 tables and 14 triggers present.
- `PRAGMA foreign_key_check`: no violations.
- `PRAGMA integrity_check`: `ok`.
- Isolated synthetic canary: **17/17 checks pass** across five successful issuance/replay cycles plus negative gates.
- Observe-only canary audit: **5/5 checks pass**.
- Safety guard: bootstrap refuses an existing target DB.
- Safety guard: synthetic canary refuses a non-empty DB.

These results prove the scripts and baseline behavior in the local file-backed test environment. They do **not** prove that genuine production traffic has already canaried successfully.

## 1. Fresh production database bootstrap

Run only for a **new database path**. The script refuses to overwrite an existing file.

```bash
python3 fresh_v3_bootstrap.py \
  --db ./data/production_sgp_v3.db \
  --schema ./schema_v3.sql \
  --report ./data/production_sgp_v3.bootstrap-report.json \
  --run-regression
```

A successful run must end with:

```text
FRESH-V3 BOOTSTRAP: PASS
```

The JSON report contains connection policy readbacks, table/trigger inventory, FK/integrity results, row counts, schema/module hashes, and regression evidence.

## 2. Isolated synthetic canary

**Do not point synthetic mode at production.** It writes synthetic immutable history and intentionally refuses a non-empty database.

Create a dedicated clean canary database:

```bash
python3 fresh_v3_bootstrap.py \
  --db ./data/layer5_isolated_canary.db \
  --schema ./schema_v3.sql
```

Run the synthetic canary:

```bash
python3 layer5_canary.py \
  --db ./data/layer5_isolated_canary.db \
  --mode synthetic \
  --iterations 5 \
  --report ./data/layer5_isolated_canary.report.json
```

Synthetic mode verifies:

- successful executable issuance;
- server-generated `price_id`;
- durable replay after quote repository eviction;
- same request ID + changed semantics conflict;
- expired quote rejection;
- ineligible artifact audit-only path;
- direct-SQL executable snapshot rejection for an ineligible artifact;
- immutable-history enforcement;
- post-canary FK/integrity checks;
- exact synthetic row accounting.

`--iterations` is only a canary harness setting. It is **not** a Layer-5 pricing/model threshold.

## 3. Genuine production controlled canary

Synthetic mode is not a substitute for real application traffic.

For a real controlled canary:

1. Bootstrap the new production V3 DB.
2. Configure the application to use the V3 Layer-5 persistence path.
3. Keep global rollout disabled.
4. Route a deliberately small controlled set of **genuine application pricing requests** through the normal authoritative quote repository and Layer-5 issuance path.
5. Confirm the application returned executable IDs only after successful commits.
6. Run observe-only verification:

```bash
python3 layer5_canary.py \
  --db ./data/production_sgp_v3.db \
  --mode observe \
  --report ./data/production_sgp_v3.observe-report.json
```

Observe mode performs no writes. It verifies:

- FK enforcement;
- busy timeout;
- WAL mode;
- `PRAGMA foreign_key_check`;
- `PRAGMA integrity_check`;
- durable Layer-5 row counts for review.

Production/global pricing should remain disabled until the genuine-traffic canary has been observed and accepted.

## 4. Important clean-start designation

There is no V2 database available. Therefore this release is a **fresh V3 initialization**, not a historical V2→V3 migration. No historical Layer-5 records are invented or imported.

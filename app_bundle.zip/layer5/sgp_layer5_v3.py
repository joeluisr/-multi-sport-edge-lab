from __future__ import annotations

import copy
import hashlib
import math
import os
import sqlite3
import time
import uuid
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Mapping, MutableMapping, Sequence

try:
    import orjson
except ImportError as exc:  # pragma: no cover - environment guard
    raise RuntimeError("orjson is required for ECMAScript-compatible primitive serialization") from exc


ARTIFACT_SCHEMA_VERSION = "SGP_PROV_V1"
PRNG_ALGORITHM = "SFC32"
SGP_SIM_MAX_SAMPLES = 5_000_000
SGP_SIM_MAX_DIMENSION = 12
MAX_ABS_STD_ERROR = 1e-3
MAX_REL_STD_ERROR = 0.10
MIN_POSITIVE_PAIRS_FOR_PRICE = 50
MIN_SIM_SAMPLES = 100_000
SHA256_HEX_CHARS = frozenset("0123456789abcdef")
SEED_HEX_LEN = 32
BUSY_TIMEOUT_MS = 5000

ALLOWED_RESOLUTION_STATUSES = frozenset(
    {"VERIFIED", "INSUFFICIENT_TAIL_RESOLUTION", "PRECISION_LOW"}
)

_HASH_FIELDS = (
    "simulation_engine_hash",
    "marginal_artifact_hash",
    "matrix_artifact_hash",
    "cholesky_factor_hash",
    "replay_input_hash",
)


class Layer5Error(RuntimeError):
    pass


@dataclass(frozen=True)
class PreparedArtifact:
    pricing_artifact_hash: str
    ordered_quote_ids_hash: str
    dimension: int
    ordered_quote_ids: tuple[str, ...]
    price_eligible: bool
    resolution_status: str
    final_joint_probability: float | None
    raw_pair_standard_error: float
    relative_standard_error: float | None
    samples_evaluated: int
    min_samples: int
    pair_count: int
    positive_pair_count: int
    precision_satisfied: bool
    tail_resolution_satisfied: bool
    canonical_payload: str
    canonical_ordered_quote_ids: str
    normalized_artifact: Mapping[str, Any]


@dataclass(frozen=True)
class PreparedVector:
    vector_id: str
    pricing_artifact_hash: str
    vector_index: int
    quote_id: str
    vector_data: str


@dataclass(frozen=True)
class PreparedQuote:
    execution_quote_id: str
    pricing_artifact_hash: str
    ordered_quote_ids_hash: str
    slip_fingerprint: str
    sportsbook: str
    american_odds: int
    decimal_odds: float
    expires_at: int
    canonical_payload: str
    quote_hash: str


# ---------------------------------------------------------------------------
# Frozen canonical serializer compatibility layer
# ---------------------------------------------------------------------------

def _utf16_sort_key(value: str) -> tuple[int, ...]:
    raw = value.encode("utf-16-be", "surrogatepass")
    return tuple((raw[i] << 8) | raw[i + 1] for i in range(0, len(raw), 2))


def _js_number_string(value: int | float) -> str:
    if isinstance(value, bool):
        raise TypeError("boolean is not a number for canonical serialization")
    if isinstance(value, int):
        return str(value)
    if not isinstance(value, float) or not math.isfinite(value):
        raise TypeError("canonical JSON rejects non-finite numbers")
    if value == 0.0:
        return "0"

    abs_value = abs(value)
    primitive = orjson.dumps(value).decode("utf-8")

    # ECMAScript JSON.stringify uses fixed notation for [1e-6, 1e21).
    if 1e-6 <= abs_value < 1e21:
        dec = Decimal(primitive)
        text = format(dec, "f")
        if "." in text:
            text = text.rstrip("0").rstrip(".")
        return text

    # orjson uses Ryu shortest-roundtrip exponent form with the same sign
    # convention required here; normalize a possible exponent leading zero.
    if "e" in primitive:
        mantissa, exponent = primitive.split("e", 1)
        sign = ""
        if exponent.startswith(("+", "-")):
            sign, exponent = exponent[0], exponent[1:]
        exponent = exponent.lstrip("0") or "0"
        return f"{mantissa}e{sign}{exponent}"
    return primitive


def canonical_json_stringify(value: Any) -> str:
    """Python port of the frozen recursively-key-sorted Node canonical serializer."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return orjson.dumps(value).decode("utf-8")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return _js_number_string(value)
    if isinstance(value, list):
        return "[" + ",".join(canonical_json_stringify(item) for item in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise TypeError("canonical JSON object keys must be strings")
        keys = sorted(value.keys(), key=_utf16_sort_key)
        return "{" + ",".join(
            f"{orjson.dumps(key).decode('utf-8')}:{canonical_json_stringify(value[key])}"
            for key in keys
        ) + "}"
    raise TypeError(f"unsupported canonical JSON value type: {type(value).__name__}")


def calculate_sha256(payload: str) -> str:
    if not isinstance(payload, str):
        raise TypeError("SHA-256 payload must be text")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _is_lower_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and value == value.lower()
        and all(ch in SHA256_HEX_CHARS for ch in value)
    )


def _require_nonempty_trimmed_id(name: str, value: Any) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise Layer5Error(f"ERR_SGP_{name.upper()}_INVALID")
    return value


def _require_finite_number(name: str, value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise Layer5Error(f"ERR_SGP_{name.upper()}_INVALID")
    return float(value)


def _normalize_hash(value: Any, name: str) -> str:
    if not isinstance(value, str):
        raise Layer5Error(f"ERR_SGP_{name.upper()}_INVALID")
    normalized = value.lower()
    if not _is_lower_sha256(normalized):
        raise Layer5Error(f"ERR_SGP_{name.upper()}_INVALID")
    return normalized


def _normalize_seed(value: Any) -> str:
    if not isinstance(value, str) or len(value) != SEED_HEX_LEN:
        raise Layer5Error("ERR_SGP_SIMULATION_SEED_INVALID")
    normalized = value.lower()
    if any(ch not in SHA256_HEX_CHARS for ch in normalized):
        raise Layer5Error("ERR_SGP_SIMULATION_SEED_INVALID")
    return normalized


def normalize_artifact_for_persistence(artifact: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(artifact, Mapping):
        raise Layer5Error("ERR_SGP_PERSISTENCE_ARTIFACT_INVALID")
    normalized = copy.deepcopy(dict(artifact))

    if "pricing_artifact_hash" in normalized and isinstance(normalized["pricing_artifact_hash"], str):
        normalized["pricing_artifact_hash"] = normalized["pricing_artifact_hash"].lower()
    for field in _HASH_FIELDS:
        if field in normalized:
            normalized[field] = _normalize_hash(normalized[field], field)
    if "simulation_seed" in normalized:
        normalized["simulation_seed"] = _normalize_seed(normalized["simulation_seed"])
    if "prng_algorithm" in normalized and normalized["prng_algorithm"] != PRNG_ALGORITHM:
        raise Layer5Error("ERR_SGP_PRNG_ALGORITHM_INVALID")
    return normalized


def build_pricing_artifact_content_payload(artifact: Mapping[str, Any]) -> dict[str, Any]:
    payload = copy.deepcopy(dict(artifact))
    payload.pop("pricing_artifact_hash", None)
    payload.pop("created_at", None)
    return payload


def _canonical_ordered_quote_ids(ordered_quote_ids: Sequence[str]) -> tuple[str, str]:
    canonical = canonical_json_stringify(list(ordered_quote_ids))
    return canonical, calculate_sha256(canonical)


def prepare_artifact(artifact: Mapping[str, Any], *, verify_hash: bool = True) -> PreparedArtifact:
    normalized = normalize_artifact_for_persistence(artifact)

    required = (
        "artifact_schema_version",
        "pricing_artifact_hash",
        "simulation_engine_version",
        "simulation_engine_hash",
        "prng_algorithm",
        "prng_policy_version",
        "model_version",
        "marginal_artifact_hash",
        "ordered_leg_ids",
        "ordered_quote_ids",
        "matrix_dimension",
        "matrix_artifact_hash",
        "cholesky_factor_hash",
        "matrix_serialization_version",
        "simulation_seed",
        "thresholds",
        "replay_input_hash",
        "min_samples",
        "max_samples",
        "target_standard_error",
        "min_positive_pairs_for_price",
        "batch_pairs",
        "samples_evaluated",
        "pair_count",
        "positive_pair_count",
        "total_hits",
        "raw_pair_standard_error",
        "relative_standard_error",
        "precision_satisfied",
        "tail_resolution_satisfied",
        "stopped_early",
        "empirical_probability",
        "final_joint_probability",
        "price_eligible",
        "resolution_status",
    )
    missing = [name for name in required if name not in normalized]
    if missing:
        raise Layer5Error("ERR_SGP_PERSISTENCE_ARTIFACT_MISSING_FIELDS: " + ",".join(missing))

    if normalized["artifact_schema_version"] != ARTIFACT_SCHEMA_VERSION:
        raise Layer5Error("ERR_SGP_ARTIFACT_SCHEMA_VERSION_INVALID")
    if not _is_lower_sha256(normalized["pricing_artifact_hash"]):
        raise Layer5Error("ERR_SGP_PRICING_ARTIFACT_HASH_INVALID")

    dimension = normalized["matrix_dimension"]
    if not isinstance(dimension, int) or isinstance(dimension, bool) or not (1 <= dimension <= SGP_SIM_MAX_DIMENSION):
        raise Layer5Error("ERR_SGP_PERSISTENCE_DIMENSION_INVALID")

    ordered_legs = normalized["ordered_leg_ids"]
    ordered_quotes = normalized["ordered_quote_ids"]
    thresholds = normalized["thresholds"]
    if not isinstance(ordered_legs, list) or len(ordered_legs) != dimension:
        raise Layer5Error("ERR_SGP_ORDERED_LEG_IDS_INVALID")
    if not isinstance(ordered_quotes, list) or len(ordered_quotes) != dimension:
        raise Layer5Error("ERR_SGP_ORDERED_QUOTE_IDS_INVALID")
    if not isinstance(thresholds, list) or len(thresholds) != dimension:
        raise Layer5Error("ERR_SGP_THRESHOLDS_INVALID")

    for value in ordered_legs:
        _require_nonempty_trimmed_id("ordered_leg_id", value)
    for value in ordered_quotes:
        _require_nonempty_trimmed_id("ordered_quote_id", value)
    if len(set(ordered_legs)) != dimension:
        raise Layer5Error("ERR_SGP_DUPLICATE_ORDERED_LEG_ID")
    if len(set(ordered_quotes)) != dimension:
        raise Layer5Error("ERR_SGP_DUPLICATE_ORDERED_QUOTE_ID")
    for threshold in thresholds:
        _require_finite_number("threshold", threshold)

    for field in (
        "simulation_engine_version",
        "prng_policy_version",
        "model_version",
        "matrix_serialization_version",
    ):
        _require_nonempty_trimmed_id(field, normalized[field])

    min_samples = normalized["min_samples"]
    max_samples = normalized["max_samples"]
    samples_evaluated = normalized["samples_evaluated"]
    pair_count = normalized["pair_count"]
    positive_pair_count = normalized["positive_pair_count"]
    min_positive = normalized["min_positive_pairs_for_price"]
    batch_pairs = normalized["batch_pairs"]
    total_hits = normalized["total_hits"]

    for field, value in (
        ("min_samples", min_samples),
        ("max_samples", max_samples),
        ("samples_evaluated", samples_evaluated),
        ("pair_count", pair_count),
        ("positive_pair_count", positive_pair_count),
        ("min_positive_pairs_for_price", min_positive),
        ("batch_pairs", batch_pairs),
        ("total_hits", total_hits),
    ):
        if not isinstance(value, int) or isinstance(value, bool):
            raise Layer5Error(f"ERR_SGP_{field.upper()}_INVALID")

    if min_samples < MIN_SIM_SAMPLES or min_samples % 2:
        raise Layer5Error("ERR_SGP_MIN_SAMPLES_INVALID")
    if max_samples < min_samples or max_samples > SGP_SIM_MAX_SAMPLES or max_samples % 2:
        raise Layer5Error("ERR_SGP_MAX_SAMPLES_INVALID")
    if samples_evaluated < min_samples or samples_evaluated > max_samples or samples_evaluated % 2:
        raise Layer5Error("ERR_SGP_SAMPLES_EVALUATED_INVALID")
    if pair_count < 0 or pair_count * 2 != samples_evaluated:
        raise Layer5Error("ERR_SGP_PAIR_COUNT_INVALID")
    if positive_pair_count < 0 or positive_pair_count > pair_count:
        raise Layer5Error("ERR_SGP_POSITIVE_PAIR_COUNT_INVALID")
    if total_hits < 0 or total_hits > samples_evaluated:
        raise Layer5Error("ERR_SGP_TOTAL_HITS_INVALID")
    if min_positive < MIN_POSITIVE_PAIRS_FOR_PRICE:
        raise Layer5Error("ERR_SGP_MIN_POSITIVE_PAIRS_INVALID")
    if batch_pairs <= 0:
        raise Layer5Error("ERR_SGP_BATCH_PAIRS_INVALID")

    target_se = _require_finite_number("target_standard_error", normalized["target_standard_error"])
    raw_se = _require_finite_number("raw_pair_standard_error", normalized["raw_pair_standard_error"])
    rel_se_raw = normalized["relative_standard_error"]
    rel_se = None if rel_se_raw is None else _require_finite_number("relative_standard_error", rel_se_raw)
    if target_se <= 0.0 or raw_se < 0.0 or (rel_se is not None and rel_se < 0.0):
        raise Layer5Error("ERR_SGP_STANDARD_ERROR_INVALID")

    empirical = _require_finite_number("empirical_probability", normalized["empirical_probability"])
    if not 0.0 <= empirical <= 1.0:
        raise Layer5Error("ERR_SGP_EMPIRICAL_PROBABILITY_INVALID")

    precision_expected = (
        samples_evaluated >= min_samples
        and raw_se <= target_se
        and raw_se <= MAX_ABS_STD_ERROR
        and rel_se is not None
        and rel_se <= MAX_REL_STD_ERROR
    )
    tail_expected = positive_pair_count >= min_positive
    eligible_expected = precision_expected and tail_expected

    precision_flag = normalized["precision_satisfied"] is True
    tail_flag = normalized["tail_resolution_satisfied"] is True
    eligible_flag = normalized["price_eligible"] is True
    if precision_flag != precision_expected:
        raise Layer5Error("ERR_SGP_PRECISION_STATE_CONTRADICTION")
    if tail_flag != tail_expected:
        raise Layer5Error("ERR_SGP_TAIL_STATE_CONTRADICTION")
    if eligible_flag != eligible_expected:
        raise Layer5Error("ERR_SGP_PRICE_ELIGIBILITY_CONTRADICTION")

    status = normalized["resolution_status"]
    if status not in ALLOWED_RESOLUTION_STATUSES:
        raise Layer5Error("ERR_SGP_RESOLUTION_STATUS_INVALID")
    expected_status = (
        "VERIFIED"
        if eligible_expected
        else ("INSUFFICIENT_TAIL_RESOLUTION" if not tail_expected else "PRECISION_LOW")
    )
    if status != expected_status:
        raise Layer5Error("ERR_SGP_RESOLUTION_STATUS_CONTRADICTION")

    final_probability = normalized["final_joint_probability"]
    if eligible_flag:
        final_probability = _require_finite_number("final_joint_probability", final_probability)
        if not 0.0 < final_probability < 1.0:
            raise Layer5Error("ERR_SGP_FINAL_JOINT_PROBABILITY_INVALID")
    else:
        if final_probability is not None:
            raise Layer5Error("ERR_SGP_INELIGIBLE_STATE_CONTRADICTION")

    if not isinstance(normalized["stopped_early"], bool):
        raise Layer5Error("ERR_SGP_STOPPED_EARLY_INVALID")

    content_payload = build_pricing_artifact_content_payload(normalized)
    canonical_payload = canonical_json_stringify(content_payload)
    calculated_hash = calculate_sha256(canonical_payload)
    if verify_hash and calculated_hash != normalized["pricing_artifact_hash"]:
        raise Layer5Error("ERR_SGP_ARTIFACT_HASH_CORRUPTION")

    canonical_quotes, ordered_quote_hash = _canonical_ordered_quote_ids(ordered_quotes)

    return PreparedArtifact(
        pricing_artifact_hash=normalized["pricing_artifact_hash"],
        ordered_quote_ids_hash=ordered_quote_hash,
        dimension=dimension,
        ordered_quote_ids=tuple(ordered_quotes),
        price_eligible=eligible_flag,
        resolution_status=status,
        final_joint_probability=final_probability,
        raw_pair_standard_error=raw_se,
        relative_standard_error=rel_se,
        samples_evaluated=samples_evaluated,
        min_samples=min_samples,
        pair_count=pair_count,
        positive_pair_count=positive_pair_count,
        precision_satisfied=precision_flag,
        tail_resolution_satisfied=tail_flag,
        canonical_payload=canonical_payload,
        canonical_ordered_quote_ids=canonical_quotes,
        normalized_artifact=normalized,
    )


def finalize_artifact(content: Mapping[str, Any], *, created_at: int | None = None) -> dict[str, Any]:
    artifact = normalize_artifact_for_persistence(content)
    artifact.pop("pricing_artifact_hash", None)
    artifact.pop("created_at", None)
    canonical = canonical_json_stringify(artifact)
    result = dict(artifact)
    result["pricing_artifact_hash"] = calculate_sha256(canonical)
    if created_at is not None:
        result["created_at"] = int(created_at)
    return result


def prepare_vectors(prepared_artifact: PreparedArtifact, vector_payloads: Sequence[Mapping[str, Any]]) -> tuple[PreparedVector, ...]:
    if not isinstance(vector_payloads, Sequence) or isinstance(vector_payloads, (str, bytes)):
        raise Layer5Error("ERR_SGP_PERSISTENCE_VECTOR_SET_INVALID")
    if len(vector_payloads) != prepared_artifact.dimension:
        raise Layer5Error("ERR_SGP_PERSISTENCE_INPUT_STRUCTURE_MISMATCH")

    by_quote: dict[str, Mapping[str, Any]] = {}
    for vector in vector_payloads:
        if not isinstance(vector, Mapping):
            raise Layer5Error("ERR_SGP_PERSISTENCE_VECTOR_INVALID")
        quote_id = vector.get("quote_id")
        vector_id = vector.get("vector_id")
        _require_nonempty_trimmed_id("vector_quote_id", quote_id)
        _require_nonempty_trimmed_id("vector_id", vector_id)
        if quote_id in by_quote:
            raise Layer5Error("ERR_SGP_PERSISTENCE_DUPLICATE_VECTOR_QUOTE")
        by_quote[quote_id] = vector

    prepared: list[PreparedVector] = []
    for idx, quote_id in enumerate(prepared_artifact.ordered_quote_ids):
        vector = by_quote.get(quote_id)
        if vector is None:
            raise Layer5Error(f"ERR_SGP_PERSISTENCE_MISSING_VECTOR_FOR_QUOTE: {quote_id}")
        if "data" not in vector:
            raise Layer5Error("ERR_SGP_PERSISTENCE_VECTOR_DATA_MISSING")
        vector_data = canonical_json_stringify(vector["data"])
        prepared.append(
            PreparedVector(
                vector_id=vector["vector_id"],
                pricing_artifact_hash=prepared_artifact.pricing_artifact_hash,
                vector_index=idx,
                quote_id=quote_id,
                vector_data=vector_data,
            )
        )
    return tuple(prepared)


def _prepare_quote(server_quote: Mapping[str, Any], prepared_artifact: PreparedArtifact, execution_quote_id: str, slip_fingerprint: str) -> PreparedQuote:
    if not isinstance(server_quote, Mapping):
        raise Layer5Error("ERR_SGP_PERSISTENCE_EXECUTION_QUOTE_NOT_FOUND")
    required = (
        "execution_quote_id",
        "pricing_artifact_hash",
        "ordered_quote_ids_hash",
        "slip_fingerprint",
        "sportsbook",
        "american_odds",
        "decimal_odds",
        "expires_at",
    )
    if any(field not in server_quote for field in required):
        raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_AUTHORITY_MISMATCH")

    quote_hash_input = str(server_quote["ordered_quote_ids_hash"]).lower()
    quote_slip = str(server_quote["slip_fingerprint"]).lower()
    quote_artifact = str(server_quote["pricing_artifact_hash"]).lower()
    if (
        quote_artifact != prepared_artifact.pricing_artifact_hash
        or quote_hash_input != prepared_artifact.ordered_quote_ids_hash
        or server_quote["execution_quote_id"] != execution_quote_id
        or quote_slip != slip_fingerprint
    ):
        raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_AUTHORITY_MISMATCH")

    sportsbook = _require_nonempty_trimmed_id("sportsbook", server_quote["sportsbook"])
    american = server_quote["american_odds"]
    decimal = server_quote["decimal_odds"]
    expires_at = server_quote["expires_at"]
    if not isinstance(american, int) or isinstance(american, bool) or not (-10000 <= american <= -100 or 100 <= american <= 10000):
        raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_ODDS_INVALID")
    decimal = _require_finite_number("decimal_odds", decimal)
    if decimal <= 1.0:
        raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_ODDS_INVALID")
    if not isinstance(expires_at, int) or isinstance(expires_at, bool) or expires_at <= 0:
        raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_EXPIRY_INVALID")

    quote_identity_payload = {
        "execution_quote_id": execution_quote_id,
        "pricing_artifact_hash": prepared_artifact.pricing_artifact_hash,
        "ordered_quote_ids_hash": prepared_artifact.ordered_quote_ids_hash,
        "slip_fingerprint": quote_slip,
        "sportsbook": sportsbook,
        "american_odds": american,
        "decimal_odds": decimal,
        "expires_at": expires_at,
    }
    canonical_quote = canonical_json_stringify(quote_identity_payload)
    quote_hash = calculate_sha256(canonical_quote)
    return PreparedQuote(
        execution_quote_id=execution_quote_id,
        pricing_artifact_hash=prepared_artifact.pricing_artifact_hash,
        ordered_quote_ids_hash=prepared_artifact.ordered_quote_ids_hash,
        slip_fingerprint=quote_slip,
        sportsbook=sportsbook,
        american_odds=american,
        decimal_odds=decimal,
        expires_at=expires_at,
        canonical_payload=canonical_quote,
        quote_hash=quote_hash,
    )


class Layer5PersistenceV3:
    def __init__(self, db_path: str | os.PathLike[str], schema_path: str | os.PathLike[str] | None = None):
        self.db_path = str(db_path)
        self.is_memory = self.db_path == ":memory:"
        self.schema_path = Path(schema_path) if schema_path else Path(__file__).with_name("schema_v3.sql")

    @classmethod
    def bootstrap(cls, db_path: str | os.PathLike[str], schema_path: str | os.PathLike[str] | None = None) -> "Layer5PersistenceV3":
        engine = cls(db_path, schema_path)
        raw = sqlite3.connect(engine.db_path, timeout=5.0, isolation_level=None)
        try:
            raw.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS};")
            raw.execute("PRAGMA foreign_keys = ON;")
            if not engine.is_memory:
                mode = raw.execute("PRAGMA journal_mode = WAL;").fetchone()[0]
                if str(mode).lower() != "wal":
                    raise Layer5Error("ERR_SQLITE_WAL_BOOTSTRAP_FAILED")
            schema = engine.schema_path.read_text(encoding="utf-8")
            raw.executescript("BEGIN IMMEDIATE;\n" + schema + "\nCOMMIT;")
        except Exception:
            try:
                raw.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            raise
        finally:
            raw.close()
        engine.verify_operational_connection()
        engine.verify_schema_structure()
        return engine

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=5.0, isolation_level=None)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys = ON;")
            conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS};")
            fk = conn.execute("PRAGMA foreign_keys;").fetchone()[0]
            if fk != 1:
                raise Layer5Error("ERR_SQLITE_FOREIGN_KEYS_NOT_ENABLED")
            timeout_ms = conn.execute("PRAGMA busy_timeout;").fetchone()[0]
            if int(timeout_ms) < BUSY_TIMEOUT_MS:
                raise Layer5Error("ERR_SQLITE_BUSY_TIMEOUT_NOT_CONFIGURED")
            if not self.is_memory:
                mode = conn.execute("PRAGMA journal_mode;").fetchone()[0]
                if str(mode).lower() != "wal":
                    raise Layer5Error("ERR_SQLITE_WAL_NOT_ENABLED")
            return conn
        except Exception:
            conn.close()
            raise

    def verify_operational_connection(self) -> dict[str, Any]:
        conn = self._get_connection()
        try:
            return {
                "foreign_keys": conn.execute("PRAGMA foreign_keys;").fetchone()[0],
                "busy_timeout": conn.execute("PRAGMA busy_timeout;").fetchone()[0],
                "journal_mode": conn.execute("PRAGMA journal_mode;").fetchone()[0],
            }
        finally:
            conn.close()

    def verify_schema_structure(self) -> None:
        required_tables = {
            "sgp_pricing_artifacts_v3",
            "artifact_quote_members_v3",
            "price_vectors_v3",
            "execution_snapshots_v3",
            "client_requests_v3",
        }
        required_triggers = {
            "trg_v3_prevent_upd_artifact",
            "trg_v3_prevent_del_artifact",
            "trg_v3_prevent_upd_members",
            "trg_v3_prevent_del_members",
            "trg_v3_prevent_upd_vectors",
            "trg_v3_prevent_del_vectors",
            "trg_v3_prevent_upd_snapshot",
            "trg_v3_prevent_del_snapshot",
            "trg_v3_prevent_upd_request",
            "trg_v3_prevent_del_request",
            "trg_v3_member_json_array_alignment",
            "trg_v3_member_dimension_bounds",
            "trg_v3_snapshot_authority",
            "trg_v3_exec_price_authority",
        }
        conn = self._get_connection()
        try:
            tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table';")}
            triggers = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger';")}
            if not required_tables.issubset(tables):
                raise Layer5Error("ERR_BOOT_SCHEMA_V3_TABLE_MISSING")
            if not required_triggers.issubset(triggers):
                raise Layer5Error("ERR_BOOT_SCHEMA_V3_TRIGGER_MISSING")
            fk_violations = conn.execute("PRAGMA foreign_key_check;").fetchall()
            if fk_violations:
                raise Layer5Error("ERR_BOOT_SCHEMA_V3_FOREIGN_KEY_VIOLATION")
        finally:
            conn.close()

    @staticmethod
    def _artifact_projection_params(artifact: PreparedArtifact) -> tuple[Any, ...]:
        return (
            artifact.pricing_artifact_hash,
            artifact.ordered_quote_ids_hash,
            artifact.dimension,
            artifact.canonical_ordered_quote_ids,
            int(artifact.price_eligible),
            artifact.resolution_status,
            artifact.final_joint_probability,
            artifact.raw_pair_standard_error,
            artifact.relative_standard_error,
            artifact.samples_evaluated,
            artifact.min_samples,
            artifact.pair_count,
            artifact.positive_pair_count,
            int(artifact.precision_satisfied),
            int(artifact.tail_resolution_satisfied),
            artifact.canonical_payload,
        )

    @staticmethod
    def _artifact_row_matches(row: sqlite3.Row, artifact: PreparedArtifact) -> bool:
        return (
            row["pricing_artifact_hash"] == artifact.pricing_artifact_hash
            and row["ordered_quote_ids_hash"] == artifact.ordered_quote_ids_hash
            and int(row["matrix_dimension"]) == artifact.dimension
            and row["canonical_ordered_quote_ids"] == artifact.canonical_ordered_quote_ids
            and int(row["price_eligible"]) == int(artifact.price_eligible)
            and row["resolution_status"] == artifact.resolution_status
            and row["final_joint_probability"] == artifact.final_joint_probability
            and row["raw_pair_standard_error"] == artifact.raw_pair_standard_error
            and row["relative_standard_error"] == artifact.relative_standard_error
            and int(row["samples_evaluated"]) == artifact.samples_evaluated
            and int(row["min_samples"]) == artifact.min_samples
            and int(row["pair_count"]) == artifact.pair_count
            and int(row["positive_pair_count"]) == artifact.positive_pair_count
            and int(row["precision_satisfied"]) == int(artifact.precision_satisfied)
            and int(row["tail_resolution_satisfied"]) == int(artifact.tail_resolution_satisfied)
            and row["canonical_payload"] == artifact.canonical_payload
        )

    @staticmethod
    def _select_artifact(conn: sqlite3.Connection, artifact_hash: str) -> sqlite3.Row | None:
        return conn.execute(
            """
            SELECT pricing_artifact_hash, ordered_quote_ids_hash, matrix_dimension,
                   canonical_ordered_quote_ids, price_eligible, resolution_status,
                   final_joint_probability, raw_pair_standard_error,
                   relative_standard_error, samples_evaluated, min_samples,
                   pair_count, positive_pair_count, precision_satisfied,
                   tail_resolution_satisfied, canonical_payload
              FROM sgp_pricing_artifacts_v3
             WHERE pricing_artifact_hash = ?
             LIMIT 1;
            """,
            (artifact_hash,),
        ).fetchone()

    @staticmethod
    def _verify_existing_vectors(conn: sqlite3.Connection, artifact: PreparedArtifact, vectors: Sequence[PreparedVector]) -> None:
        rows = conn.execute(
            """
            SELECT m.vector_index, m.quote_id, v.vector_id, v.vector_data
              FROM artifact_quote_members_v3 m
              JOIN price_vectors_v3 v
                ON v.pricing_artifact_hash = m.pricing_artifact_hash
               AND v.vector_index = m.vector_index
               AND v.quote_id = m.quote_id
             WHERE m.pricing_artifact_hash = ?
             ORDER BY m.vector_index ASC;
            """,
            (artifact.pricing_artifact_hash,),
        ).fetchall()
        if len(rows) != artifact.dimension:
            raise Layer5Error("ERR_SGP_PERSISTENCE_DEPENDENT_HISTORY_INCOMPLETE")
        for idx, row in enumerate(rows):
            expected = vectors[idx]
            if (
                int(row["vector_index"]) != idx
                or row["quote_id"] != expected.quote_id
                or row["vector_id"] != expected.vector_id
                or row["vector_data"] != expected.vector_data
            ):
                raise Layer5Error("ERR_SGP_PERSISTENCE_DEPENDENT_SEGMENT_CORRUPTED")

    def _ensure_artifact_and_vectors(
        self,
        conn: sqlite3.Connection,
        artifact: PreparedArtifact,
        vectors: Sequence[PreparedVector],
    ) -> str:
        existing = self._select_artifact(conn, artifact.pricing_artifact_hash)
        if existing is not None:
            if not self._artifact_row_matches(existing, artifact):
                raise Layer5Error("ERR_PRICING_ARTIFACT_IDENTITY_COLLISION")
            self._verify_existing_vectors(conn, artifact, vectors)
            return existing["pricing_artifact_hash"]

        conn.execute(
            """
            INSERT INTO sgp_pricing_artifacts_v3 (
                pricing_artifact_hash, ordered_quote_ids_hash, matrix_dimension,
                canonical_ordered_quote_ids, price_eligible, resolution_status,
                final_joint_probability, raw_pair_standard_error,
                relative_standard_error, samples_evaluated, min_samples,
                pair_count, positive_pair_count, precision_satisfied,
                tail_resolution_satisfied, canonical_payload
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            self._artifact_projection_params(artifact),
        )
        for vector in vectors:
            conn.execute(
                """
                INSERT INTO artifact_quote_members_v3
                    (pricing_artifact_hash, vector_index, quote_id)
                VALUES (?, ?, ?);
                """,
                (vector.pricing_artifact_hash, vector.vector_index, vector.quote_id),
            )
            conn.execute(
                """
                INSERT INTO price_vectors_v3
                    (vector_id, pricing_artifact_hash, vector_index, quote_id, vector_data)
                VALUES (?, ?, ?, ?, ?);
                """,
                (
                    vector.vector_id,
                    vector.pricing_artifact_hash,
                    vector.vector_index,
                    vector.quote_id,
                    vector.vector_data,
                ),
            )
        return artifact.pricing_artifact_hash

    def register_pricing_artifact(self, artifact_input: Mapping[str, Any], vector_payloads: Sequence[Mapping[str, Any]]) -> str:
        # Registration is immutable identity resolution.  For a pre-existing ID,
        # exact canonical semantics replay; different canonical semantics collide.
        # For a new ID, the supplied content-addressed hash must authenticate the
        # canonical payload before any INSERT occurs.
        artifact = prepare_artifact(artifact_input, verify_hash=False)
        vectors = prepare_vectors(artifact, vector_payloads)
        conn = self._get_connection()
        try:
            conn.execute("BEGIN IMMEDIATE;")
            existing = self._select_artifact(conn, artifact.pricing_artifact_hash)
            if existing is not None:
                if not self._artifact_row_matches(existing, artifact):
                    raise Layer5Error("ERR_PRICING_ARTIFACT_IDENTITY_COLLISION")
                self._verify_existing_vectors(conn, artifact, vectors)
                durable_hash = existing["pricing_artifact_hash"]
            else:
                calculated_hash = calculate_sha256(artifact.canonical_payload)
                if calculated_hash != artifact.pricing_artifact_hash:
                    raise Layer5Error("ERR_SGP_ARTIFACT_HASH_CORRUPTION")
                durable_hash = self._ensure_artifact_and_vectors(conn, artifact, vectors)
            conn.execute("COMMIT;")
            return durable_hash
        except Exception:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            raise
        finally:
            conn.close()

    def persist_audit_only(self, artifact_input: Mapping[str, Any], vector_payloads: Sequence[Mapping[str, Any]]) -> str:
        artifact = prepare_artifact(artifact_input)
        if artifact.price_eligible:
            raise Layer5Error("ERR_SGP_AUDIT_PATH_REQUIRES_INELIGIBLE_ARTIFACT")
        vectors = prepare_vectors(artifact, vector_payloads)
        conn = self._get_connection()
        try:
            conn.execute("BEGIN IMMEDIATE;")
            durable_hash = self._ensure_artifact_and_vectors(conn, artifact, vectors)
            conn.execute("COMMIT;")
            return durable_hash
        except Exception:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            raise
        finally:
            conn.close()

    @staticmethod
    def _validate_request_context(request_context: Mapping[str, Any]) -> tuple[str, str]:
        if not isinstance(request_context, Mapping):
            raise Layer5Error("ERR_SGP_PERSISTENCE_REQUEST_CONTEXT_INVALID")
        request_id = request_context.get("request_id")
        slip = request_context.get("slip_fingerprint")
        if (
            not isinstance(request_id, str)
            or not 1 <= len(request_id) <= 128
            or request_id != request_id.strip()
            or not isinstance(slip, str)
        ):
            raise Layer5Error("ERR_SGP_PERSISTENCE_REQUEST_CONTEXT_INVALID")
        slip = slip.lower()
        if not _is_lower_sha256(slip):
            raise Layer5Error("ERR_SGP_PERSISTENCE_REQUEST_CONTEXT_INVALID")
        return request_id, slip

    @staticmethod
    def _validate_execution_quote_id(execution_quote_id: Any) -> str:
        if (
            not isinstance(execution_quote_id, str)
            or not 1 <= len(execution_quote_id) <= 128
            or execution_quote_id != execution_quote_id.strip()
        ):
            raise Layer5Error("ERR_SGP_PERSISTENCE_EXECUTION_QUOTE_ID_INVALID")
        return execution_quote_id

    @staticmethod
    def _probe_request(conn: sqlite3.Connection, request_id: str) -> sqlite3.Row | None:
        return conn.execute(
            """
            SELECT price_id, request_fingerprint, pricing_artifact_hash,
                   execution_quote_id, slip_fingerprint
              FROM client_requests_v3
             WHERE request_id = ?
             LIMIT 1;
            """,
            (request_id,),
        ).fetchone()

    @staticmethod
    def _repository_get(repository: Any, execution_quote_id: str) -> Mapping[str, Any] | None:
        if repository is None:
            raise Layer5Error("ERR_SGP_PERSISTENCE_QUOTE_REPOSITORY_UNAVAILABLE")
        if isinstance(repository, Mapping):
            value = repository.get(execution_quote_id)
        elif hasattr(repository, "get") and callable(repository.get):
            value = repository.get(execution_quote_id)
        elif callable(repository):
            value = repository(execution_quote_id)
        else:
            raise Layer5Error("ERR_SGP_PERSISTENCE_QUOTE_REPOSITORY_UNAVAILABLE")
        return value

    @staticmethod
    def _insert_or_verify_snapshot(conn: sqlite3.Connection, artifact: PreparedArtifact, quote: PreparedQuote) -> None:
        conn.execute(
            """
            INSERT INTO execution_snapshots_v3 (
                execution_quote_id, pricing_artifact_hash, ordered_quote_ids_hash,
                sportsbook, slip_fingerprint, american_odds, decimal_odds,
                expires_at, canonical_payload, quote_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(execution_quote_id) DO NOTHING;
            """,
            (
                quote.execution_quote_id,
                artifact.pricing_artifact_hash,
                quote.ordered_quote_ids_hash,
                quote.sportsbook,
                quote.slip_fingerprint,
                quote.american_odds,
                quote.decimal_odds,
                quote.expires_at,
                quote.canonical_payload,
                quote.quote_hash,
            ),
        )
        row = conn.execute(
            """
            SELECT pricing_artifact_hash, ordered_quote_ids_hash, sportsbook,
                   slip_fingerprint, american_odds, decimal_odds, expires_at,
                   canonical_payload, quote_hash
              FROM execution_snapshots_v3
             WHERE execution_quote_id = ? LIMIT 1;
            """,
            (quote.execution_quote_id,),
        ).fetchone()
        if row is None:
            raise Layer5Error("ERR_SGP_PERSISTENCE_SNAPSHOT_READBACK_FAILED")
        if (
            row["pricing_artifact_hash"] != artifact.pricing_artifact_hash
            or row["ordered_quote_ids_hash"] != quote.ordered_quote_ids_hash
            or row["sportsbook"] != quote.sportsbook
            or row["slip_fingerprint"] != quote.slip_fingerprint
            or int(row["american_odds"]) != quote.american_odds
            or abs(float(row["decimal_odds"]) - quote.decimal_odds) > 0.0001
            or int(row["expires_at"]) != quote.expires_at
            or row["canonical_payload"] != quote.canonical_payload
            or row["quote_hash"] != quote.quote_hash
        ):
            raise Layer5Error("ERR_SGP_EXECUTION_QUOTE_ARTIFACT_MISMATCH")

    def execute_price_issuance(
        self,
        artifact_input: Mapping[str, Any],
        vector_payloads: Sequence[Mapping[str, Any]],
        execution_quote_id: str,
        request_context: Mapping[str, Any],
        execution_quote_repository: Any,
        *,
        now_epoch: int | None = None,
    ) -> dict[str, str]:
        execution_quote_id = self._validate_execution_quote_id(execution_quote_id)
        request_id, slip_fingerprint = self._validate_request_context(request_context)
        artifact = prepare_artifact(artifact_input)
        vectors = prepare_vectors(artifact, vector_payloads)

        # Repository-independent durable replay occurs before external quote lookup.
        conn = self._get_connection()
        try:
            stored = self._probe_request(conn, request_id)
            if stored is not None:
                if (
                    stored["pricing_artifact_hash"] != artifact.pricing_artifact_hash
                    or stored["execution_quote_id"] != execution_quote_id
                    or stored["slip_fingerprint"] != slip_fingerprint
                ):
                    raise Layer5Error("ERR_IDEMPOTENCY_KEY_REUSED")
                return {"status": "IDEMPOTENT_REPLAY", "price_id": stored["price_id"]}
        finally:
            conn.close()

        if not artifact.price_eligible:
            self.persist_audit_only(artifact.normalized_artifact, vector_payloads)
            return {"status": "AUDIT_ONLY_COMMITTED", "pricing_artifact_hash": artifact.pricing_artifact_hash}

        server_quote = self._repository_get(execution_quote_repository, execution_quote_id)
        quote = _prepare_quote(server_quote, artifact, execution_quote_id, slip_fingerprint)
        request_fingerprint = calculate_sha256(
            canonical_json_stringify(
                {
                    "pricing_artifact_hash": artifact.pricing_artifact_hash,
                    "authoritative_quote_hash": quote.quote_hash,
                }
            )
        )

        now = int(time.time()) if now_epoch is None else int(now_epoch)
        if quote.expires_at <= now:
            raise Layer5Error("ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED")

        conn = self._get_connection()
        try:
            conn.execute("BEGIN IMMEDIATE;")
            race = self._probe_request(conn, request_id)
            if race is not None:
                if (
                    race["request_fingerprint"] != request_fingerprint
                    or race["pricing_artifact_hash"] != artifact.pricing_artifact_hash
                    or race["execution_quote_id"] != quote.execution_quote_id
                    or race["slip_fingerprint"] != quote.slip_fingerprint
                ):
                    raise Layer5Error("ERR_IDEMPOTENCY_KEY_REUSED")
                price_id = race["price_id"]
                conn.execute("ROLLBACK;")
                return {"status": "IDEMPOTENT_REPLAY", "price_id": price_id}

            self._ensure_artifact_and_vectors(conn, artifact, vectors)
            self._insert_or_verify_snapshot(conn, artifact, quote)

            # Re-check wall-clock expiry immediately before the executable ledger insert.
            current_now = int(time.time()) if now_epoch is None else int(now_epoch)
            if quote.expires_at <= current_now:
                raise Layer5Error("ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED")

            price_id = "prc_" + str(uuid.uuid4())
            conn.execute(
                """
                INSERT INTO client_requests_v3 (
                    request_id, request_fingerprint, pricing_artifact_hash,
                    execution_quote_id, slip_fingerprint, american_odds,
                    decimal_odds, price_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (
                    request_id,
                    request_fingerprint,
                    artifact.pricing_artifact_hash,
                    quote.execution_quote_id,
                    quote.slip_fingerprint,
                    quote.american_odds,
                    quote.decimal_odds,
                    price_id,
                ),
            )
            conn.execute("COMMIT;")
            return {"status": "SUCCESS", "price_id": price_id}
        except Exception:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            raise
        finally:
            conn.close()

    def fetch_artifact(self, artifact_hash: str) -> sqlite3.Row | None:
        conn = self._get_connection()
        try:
            return self._select_artifact(conn, artifact_hash)
        finally:
            conn.close()

-- Python compatibility port of the frozen Node/V3 Layer-5 persistence schema.
-- WAL is established by bootstrap code before this script is executed.

CREATE TABLE sgp_pricing_artifacts_v3 (
    pricing_artifact_hash TEXT PRIMARY KEY CHECK (
        length(pricing_artifact_hash) = 64
        AND pricing_artifact_hash = lower(pricing_artifact_hash)
        AND pricing_artifact_hash NOT GLOB '*[^0-9a-f]*'
    ),
    ordered_quote_ids_hash TEXT NOT NULL CHECK (
        length(ordered_quote_ids_hash) = 64
        AND ordered_quote_ids_hash = lower(ordered_quote_ids_hash)
        AND ordered_quote_ids_hash NOT GLOB '*[^0-9a-f]*'
    ),
    matrix_dimension INTEGER NOT NULL CHECK (matrix_dimension BETWEEN 1 AND 12),
    canonical_ordered_quote_ids TEXT NOT NULL,
    price_eligible INTEGER NOT NULL CHECK (price_eligible IN (0, 1)),
    resolution_status TEXT NOT NULL CHECK (
        resolution_status IN ('VERIFIED', 'INSUFFICIENT_TAIL_RESOLUTION', 'PRECISION_LOW')
    ),
    final_joint_probability REAL,
    raw_pair_standard_error REAL NOT NULL CHECK (raw_pair_standard_error >= 0.0),
    relative_standard_error REAL CHECK (
        relative_standard_error IS NULL OR relative_standard_error >= 0.0
    ),
    samples_evaluated INTEGER NOT NULL CHECK (samples_evaluated >= 100000),
    min_samples INTEGER NOT NULL CHECK (min_samples >= 100000),
    pair_count INTEGER NOT NULL CHECK (pair_count >= 0),
    positive_pair_count INTEGER NOT NULL CHECK (
        positive_pair_count >= 0 AND positive_pair_count <= pair_count
    ),
    precision_satisfied INTEGER NOT NULL CHECK (precision_satisfied IN (0, 1)),
    tail_resolution_satisfied INTEGER NOT NULL CHECK (tail_resolution_satisfied IN (0, 1)),
    canonical_payload TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    CHECK (
        json_valid(canonical_ordered_quote_ids)
        AND json_type(canonical_ordered_quote_ids) = 'array'
        AND json_array_length(canonical_ordered_quote_ids) = matrix_dimension
    ),
    CHECK (samples_evaluated >= min_samples),
    CHECK (pair_count * 2 = samples_evaluated),
    CHECK (
        (
            price_eligible = 1
            AND resolution_status = 'VERIFIED'
            AND final_joint_probability > 0.0
            AND final_joint_probability < 1.0
            AND precision_satisfied = 1
            AND tail_resolution_satisfied = 1
            AND raw_pair_standard_error <= 0.001
            AND relative_standard_error IS NOT NULL
            AND relative_standard_error <= 0.10
        )
        OR
        (
            price_eligible = 0
            AND resolution_status IN ('INSUFFICIENT_TAIL_RESOLUTION', 'PRECISION_LOW')
            AND final_joint_probability IS NULL
        )
    )
);

CREATE TABLE artifact_quote_members_v3 (
    pricing_artifact_hash TEXT NOT NULL,
    vector_index INTEGER NOT NULL CHECK (vector_index >= 0),
    quote_id TEXT NOT NULL CHECK (length(quote_id) > 0),
    PRIMARY KEY (pricing_artifact_hash, vector_index),
    UNIQUE (pricing_artifact_hash, vector_index, quote_id),
    UNIQUE (pricing_artifact_hash, quote_id),
    FOREIGN KEY (pricing_artifact_hash)
        REFERENCES sgp_pricing_artifacts_v3(pricing_artifact_hash)
        ON UPDATE RESTRICT ON DELETE RESTRICT
);

CREATE TABLE price_vectors_v3 (
    vector_id TEXT NOT NULL CHECK (length(vector_id) > 0),
    pricing_artifact_hash TEXT NOT NULL,
    vector_index INTEGER NOT NULL,
    quote_id TEXT NOT NULL,
    vector_data TEXT NOT NULL CHECK (json_valid(vector_data)),
    PRIMARY KEY (vector_id, pricing_artifact_hash),
    UNIQUE (pricing_artifact_hash, vector_index),
    FOREIGN KEY (pricing_artifact_hash, vector_index, quote_id)
        REFERENCES artifact_quote_members_v3(pricing_artifact_hash, vector_index, quote_id)
        ON UPDATE RESTRICT ON DELETE RESTRICT
);

CREATE TABLE execution_snapshots_v3 (
    execution_quote_id TEXT PRIMARY KEY CHECK (length(execution_quote_id) > 0),
    pricing_artifact_hash TEXT NOT NULL,
    ordered_quote_ids_hash TEXT NOT NULL CHECK (
        length(ordered_quote_ids_hash) = 64
        AND ordered_quote_ids_hash = lower(ordered_quote_ids_hash)
        AND ordered_quote_ids_hash NOT GLOB '*[^0-9a-f]*'
    ),
    sportsbook TEXT NOT NULL CHECK (length(sportsbook) > 0),
    slip_fingerprint TEXT NOT NULL CHECK (
        length(slip_fingerprint) = 64
        AND slip_fingerprint = lower(slip_fingerprint)
        AND slip_fingerprint NOT GLOB '*[^0-9a-f]*'
    ),
    american_odds INTEGER NOT NULL CHECK (
        american_odds BETWEEN -10000 AND -100
        OR american_odds BETWEEN 100 AND 10000
    ),
    decimal_odds REAL NOT NULL CHECK (decimal_odds > 1.0),
    expires_at INTEGER NOT NULL CHECK (expires_at > 0),
    canonical_payload TEXT NOT NULL,
    quote_hash TEXT NOT NULL CHECK (
        length(quote_hash) = 64
        AND quote_hash = lower(quote_hash)
        AND quote_hash NOT GLOB '*[^0-9a-f]*'
    ),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    FOREIGN KEY (pricing_artifact_hash)
        REFERENCES sgp_pricing_artifacts_v3(pricing_artifact_hash)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    CHECK (
        abs(
            decimal_odds -
            CASE
                WHEN american_odds > 0 THEN 1.0 + american_odds / 100.0
                ELSE 1.0 + 100.0 / abs(american_odds)
            END
        ) <= 0.005
    )
);

CREATE TABLE client_requests_v3 (
    request_id TEXT PRIMARY KEY CHECK (length(request_id) BETWEEN 1 AND 128),
    request_fingerprint TEXT NOT NULL CHECK (
        length(request_fingerprint) = 64
        AND request_fingerprint = lower(request_fingerprint)
        AND request_fingerprint NOT GLOB '*[^0-9a-f]*'
    ),
    pricing_artifact_hash TEXT NOT NULL,
    execution_quote_id TEXT NOT NULL,
    slip_fingerprint TEXT NOT NULL CHECK (
        length(slip_fingerprint) = 64
        AND slip_fingerprint = lower(slip_fingerprint)
        AND slip_fingerprint NOT GLOB '*[^0-9a-f]*'
    ),
    american_odds INTEGER NOT NULL,
    decimal_odds REAL NOT NULL,
    price_id TEXT NOT NULL UNIQUE CHECK (length(price_id) > 0),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    FOREIGN KEY (pricing_artifact_hash)
        REFERENCES sgp_pricing_artifacts_v3(pricing_artifact_hash)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    FOREIGN KEY (execution_quote_id)
        REFERENCES execution_snapshots_v3(execution_quote_id)
        ON UPDATE RESTRICT ON DELETE RESTRICT
);

-- Immutable history: all durable Layer-5 history is append-only.
CREATE TRIGGER trg_v3_prevent_upd_artifact
BEFORE UPDATE ON sgp_pricing_artifacts_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_del_artifact
BEFORE DELETE ON sgp_pricing_artifacts_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_upd_members
BEFORE UPDATE ON artifact_quote_members_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_del_members
BEFORE DELETE ON artifact_quote_members_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_upd_vectors
BEFORE UPDATE ON price_vectors_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_del_vectors
BEFORE DELETE ON price_vectors_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_upd_snapshot
BEFORE UPDATE ON execution_snapshots_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_del_snapshot
BEFORE DELETE ON execution_snapshots_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_upd_request
BEFORE UPDATE ON client_requests_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;
CREATE TRIGGER trg_v3_prevent_del_request
BEFORE DELETE ON client_requests_v3
BEGIN
    SELECT RAISE(ABORT, 'ERR_SGP_IMMUTABLE_TABLE');
END;

-- Membership is bound to the exact canonical quote position.
CREATE TRIGGER trg_v3_member_json_array_alignment
BEFORE INSERT ON artifact_quote_members_v3
BEGIN
    SELECT CASE WHEN
        json_extract(
            (SELECT canonical_ordered_quote_ids
               FROM sgp_pricing_artifacts_v3
              WHERE pricing_artifact_hash = NEW.pricing_artifact_hash),
            '$[' || NEW.vector_index || ']'
        ) IS NOT NEW.quote_id
    THEN RAISE(ABORT, 'ERR_SGP_MEMBER_JSON_ARRAY_VALUE_MISMATCH') END;
END;

CREATE TRIGGER trg_v3_member_dimension_bounds
BEFORE INSERT ON artifact_quote_members_v3
BEGIN
    SELECT CASE WHEN
        NEW.vector_index >= (
            SELECT matrix_dimension
              FROM sgp_pricing_artifacts_v3
             WHERE pricing_artifact_hash = NEW.pricing_artifact_hash
        )
    THEN RAISE(ABORT, 'ERR_SGP_MEMBER_INDEX_OUT_OF_BOUNDS') END;
END;

-- A new execution snapshot may only bind to an eligible VERIFIED artifact and
-- must use the exact ordered-quote hash projected by that artifact.
CREATE TRIGGER trg_v3_snapshot_authority
BEFORE INSERT ON execution_snapshots_v3
BEGIN
    SELECT CASE WHEN NOT EXISTS (
        SELECT 1
          FROM sgp_pricing_artifacts_v3 p
         WHERE p.pricing_artifact_hash = NEW.pricing_artifact_hash
           AND p.ordered_quote_ids_hash = NEW.ordered_quote_ids_hash
           AND p.price_eligible = 1
           AND p.resolution_status = 'VERIFIED'
           AND p.precision_satisfied = 1
           AND p.tail_resolution_satisfied = 1
           AND NEW.expires_at > CAST(strftime('%s', 'now') AS INTEGER)
    ) THEN RAISE(ABORT, 'ERR_SGP_SNAPSHOT_AUTHORITY_FAILED') END;
END;

-- Executable request authority is enforced again at the final database boundary.
CREATE TRIGGER trg_v3_exec_price_authority
BEFORE INSERT ON client_requests_v3
BEGIN
    SELECT CASE WHEN NOT EXISTS (
        SELECT 1
          FROM execution_snapshots_v3 q
          JOIN sgp_pricing_artifacts_v3 p
            ON p.pricing_artifact_hash = q.pricing_artifact_hash
         WHERE q.execution_quote_id = NEW.execution_quote_id
           AND p.pricing_artifact_hash = NEW.pricing_artifact_hash
           AND p.ordered_quote_ids_hash = q.ordered_quote_ids_hash
           AND p.price_eligible = 1
           AND p.resolution_status = 'VERIFIED'
           AND p.precision_satisfied = 1
           AND p.tail_resolution_satisfied = 1
           AND q.expires_at > CAST(strftime('%s', 'now') AS INTEGER)
           AND q.slip_fingerprint = NEW.slip_fingerprint
           AND q.american_odds = NEW.american_odds
           AND abs(q.decimal_odds - NEW.decimal_odds) <= 0.0001
           AND (
               SELECT count(*)
                 FROM artifact_quote_members_v3 m
                WHERE m.pricing_artifact_hash = p.pricing_artifact_hash
           ) = p.matrix_dimension
           AND (
               SELECT count(*)
                 FROM price_vectors_v3 v
                WHERE v.pricing_artifact_hash = p.pricing_artifact_hash
           ) = p.matrix_dimension
    ) THEN RAISE(ABORT, 'ERR_SGP_EXEC_SOURCE_ALIGNMENT_FAILED') END;
END;

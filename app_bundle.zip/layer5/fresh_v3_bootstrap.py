#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sgp_layer5_v3 import BUSY_TIMEOUT_MS, Layer5PersistenceV3

EXPECTED_TABLES = {
    "sgp_pricing_artifacts_v3",
    "artifact_quote_members_v3",
    "price_vectors_v3",
    "execution_snapshots_v3",
    "client_requests_v3",
}

EXPECTED_TRIGGERS = {
    "trg_v3_prevent_upd_artifact",
    "trg_v3_prevent_del_artifact",
    "trg_v3_prevent_upd_members",
    "trg_v3_prevent_del_members",
    "trg_v3_prevent_upd_vectors",
    "trg_v3_prevent_del_vectors",
    "trg_v3_prevent_upd_snapshot",
    "trg_v3_prevent_del_snapshot",
    "trg_v3_prevent_upd_request",
    "trg_v3_prevent_del_request",
    "trg_v3_member_json_array_alignment",
    "trg_v3_member_dimension_bounds",
    "trg_v3_snapshot_authority",
    "trg_v3_exec_price_authority",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def fail_report(report: dict[str, Any], message: str, report_path: Path | None) -> int:
    report["status"] = "FAIL"
    report["completed_at_utc"] = now_utc()
    report.setdefault("errors", []).append(message)
    print(f"\n❌ FRESH-V3 BOOTSTRAP: FAIL\n{message}")
    if report_path is not None:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print(f"Report: {report_path}")
    return 1


def verify_database(db_path: Path, engine: Layer5PersistenceV3) -> dict[str, Any]:
    engine.verify_schema_structure()
    policy = engine.verify_operational_connection()

    conn = engine._get_connection()
    try:
        sqlite_version = conn.execute("SELECT sqlite_version();").fetchone()[0]
        json1_probe = conn.execute("SELECT json_valid('[\"ok\"]');").fetchone()[0]
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
            )
        }
        triggers = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger';")
        }
        fk_violations = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check;").fetchall()]
        integrity_rows = [row[0] for row in conn.execute("PRAGMA integrity_check;").fetchall()]
        row_counts = {
            table: conn.execute(f'SELECT count(*) FROM "{table}";').fetchone()[0]
            for table in sorted(EXPECTED_TABLES)
        }
        checkpoint = tuple(conn.execute("PRAGMA wal_checkpoint(FULL);").fetchone())
    finally:
        conn.close()

    missing_tables = sorted(EXPECTED_TABLES - tables)
    missing_triggers = sorted(EXPECTED_TRIGGERS - triggers)
    extra_layer5_tables = sorted(t for t in tables if t.endswith("_v3") and t not in EXPECTED_TABLES)

    checks = {
        "file_backed_database": db_path.exists() and db_path.is_file(),
        "foreign_keys_enabled": int(policy["foreign_keys"]) == 1,
        "busy_timeout_configured": int(policy["busy_timeout"]) >= BUSY_TIMEOUT_MS,
        "wal_verified": str(policy["journal_mode"]).lower() == "wal",
        "json_functions_available": int(json1_probe) == 1,
        "required_tables_present": not missing_tables,
        "required_triggers_present": not missing_triggers,
        "foreign_key_check_clean": not fk_violations,
        "integrity_check_clean": integrity_rows == ["ok"],
        "fresh_database_empty": all(count == 0 for count in row_counts.values()),
    }

    return {
        "sqlite_version": sqlite_version,
        "connection_policy": {
            "foreign_keys": int(policy["foreign_keys"]),
            "busy_timeout": int(policy["busy_timeout"]),
            "journal_mode": str(policy["journal_mode"]).lower(),
        },
        "tables": sorted(tables),
        "triggers": sorted(triggers),
        "missing_tables": missing_tables,
        "missing_triggers": missing_triggers,
        "extra_layer5_tables": extra_layer5_tables,
        "foreign_key_violations": fk_violations,
        "integrity_check": integrity_rows,
        "row_counts": row_counts,
        "wal_checkpoint_full": checkpoint,
        "checks": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Initialize and verify a fresh file-backed Layer-5 V3 SQLite database."
    )
    parser.add_argument("--db", required=True, help="Path for the new V3 SQLite database.")
    parser.add_argument(
        "--schema",
        default=str(Path(__file__).with_name("schema_v3.sql")),
        help="Normative V3 schema path.",
    )
    parser.add_argument(
        "--report",
        default=None,
        help="Optional JSON deployment report path.",
    )
    parser.add_argument(
        "--run-regression",
        action="store_true",
        help="Run run_parity_suite.py after bootstrap and include its result in the report.",
    )
    args = parser.parse_args()

    db_path = Path(args.db).resolve()
    schema_path = Path(args.schema).resolve()
    report_path = Path(args.report).resolve() if args.report else db_path.with_suffix(db_path.suffix + ".bootstrap-report.json")

    report: dict[str, Any] = {
        "report_type": "LAYER5_FRESH_V3_BOOTSTRAP",
        "started_at_utc": now_utc(),
        "database_path": str(db_path),
        "schema_path": str(schema_path),
        "status": "RUNNING",
        "checks": {},
        "errors": [],
    }

    print("==============================================================================")
    print("LAYER-5 FRESH V3 BOOTSTRAP")
    print("==============================================================================")
    print(f"Target DB : {db_path}")
    print(f"Schema    : {schema_path}")

    if str(db_path) == ":memory:":
        return fail_report(report, "ERR_BOOTSTRAP_REQUIRES_FILE_BACKED_DATABASE", report_path)
    if not schema_path.is_file():
        return fail_report(report, "ERR_BOOTSTRAP_SCHEMA_NOT_FOUND", report_path)
    if db_path.exists():
        return fail_report(
            report,
            "ERR_BOOTSTRAP_TARGET_ALREADY_EXISTS: fresh bootstrap refuses destructive overwrite",
            report_path,
        )

    db_path.parent.mkdir(parents=True, exist_ok=True)
    report["schema_sha256"] = sha256_file(schema_path)
    module_path = Path(__file__).with_name("sgp_layer5_v3.py")
    if module_path.is_file():
        report["layer5_module_sha256"] = sha256_file(module_path)

    try:
        engine = Layer5PersistenceV3.bootstrap(db_path, schema_path)
        verification = verify_database(db_path, engine)
        report["verification"] = verification
        report["checks"].update(verification["checks"])

        if not all(verification["checks"].values()):
            failed = [name for name, ok in verification["checks"].items() if not ok]
            raise RuntimeError("bootstrap verification failed: " + ", ".join(failed))

        if args.run_regression:
            regression_script = Path(__file__).with_name("run_parity_suite.py")
            if not regression_script.is_file():
                raise RuntimeError("ERR_BOOTSTRAP_REGRESSION_SCRIPT_NOT_FOUND")
            env = dict(os.environ)
            env.setdefault("TERM", "xterm")
            proc = subprocess.run(
                [sys.executable, str(regression_script)],
                cwd=str(regression_script.parent),
                text=True,
                capture_output=True,
                env=env,
            )
            report["regression"] = {
                "returncode": proc.returncode,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "pass": proc.returncode == 0 and "SUMMARY: 18/18 fixtures passed" in proc.stdout,
            }
            report["checks"]["regression_18_of_18"] = bool(report["regression"]["pass"])
            if not report["regression"]["pass"]:
                raise RuntimeError("ERR_BOOTSTRAP_REGRESSION_FAILED")

        # Force a final checkpoint before hashing the fresh database image.
        conn = engine._get_connection()
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        finally:
            conn.close()

        report["database_sha256_after_bootstrap"] = sha256_file(db_path)
        report["database_size_bytes"] = db_path.stat().st_size
        report["status"] = "PASS"
        report["completed_at_utc"] = now_utc()
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")

        print("\n✅ FRESH-V3 BOOTSTRAP: PASS")
        for name, ok in report["checks"].items():
            print(f"  {'PASS' if ok else 'FAIL'}  {name}")
        print(f"\nDB SHA-256 : {report['database_sha256_after_bootstrap']}")
        print(f"Report      : {report_path}")
        return 0

    except Exception as exc:
        return fail_report(report, f"{type(exc).__name__}: {exc}", report_path)


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sqlite3
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sgp_layer5_v3 import (
    Layer5Error,
    Layer5PersistenceV3,
    finalize_artifact,
    prepare_artifact,
)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def canary_content(ordered_quotes: list[str]) -> dict[str, Any]:
    n = len(ordered_quotes)
    return {
        "artifact_schema_version": "SGP_PROV_V1",
        "simulation_engine_version": "SGP_MC_V1",
        "simulation_engine_hash": "1" * 64,
        "prng_algorithm": "SFC32",
        "prng_policy_version": "SFC32_POLICY_V1",
        "model_version": "MODEL_V1",
        "marginal_artifact_hash": "2" * 64,
        "ordered_leg_ids": [f"CANARY_LEG_{i + 1}" for i in range(n)],
        "ordered_quote_ids": ordered_quotes,
        "matrix_dimension": n,
        "matrix_artifact_hash": "3" * 64,
        "cholesky_factor_hash": "4" * 64,
        "matrix_serialization_version": "MAT_REPACK_V1",
        "simulation_seed": "0123456789abcdef0123456789abcdef",
        "thresholds": [0.25 + i * 0.1 for i in range(n)],
        "replay_input_hash": "5" * 64,
        "min_samples": 100000,
        "max_samples": 500000,
        "target_standard_error": 0.0005,
        "min_positive_pairs_for_price": 50,
        "batch_pairs": 5000,
        "samples_evaluated": 100000,
        "pair_count": 50000,
        "positive_pair_count": 100,
        "total_hits": 20000,
        "raw_pair_standard_error": 0.0004,
        "relative_standard_error": 0.02,
        "precision_satisfied": True,
        "tail_resolution_satisfied": True,
        "stopped_early": False,
        "empirical_probability": 0.20,
        "final_joint_probability": 0.20,
        "price_eligible": True,
        "resolution_status": "VERIFIED",
    }


def vectors_for(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "vector_id": f"CANARY_VEC_{i + 1}",
            "quote_id": qid,
            "data": {"quote_id": qid, "marginal_probability": 0.55 + i * 0.01},
        }
        for i, qid in enumerate(artifact["ordered_quote_ids"])
    ]


def quote_for(
    artifact: dict[str, Any],
    *,
    execution_quote_id: str,
    slip_fingerprint: str,
    expires_at: int,
) -> dict[str, Any]:
    prepared = prepare_artifact(artifact)
    return {
        "execution_quote_id": execution_quote_id,
        "pricing_artifact_hash": prepared.pricing_artifact_hash,
        "ordered_quote_ids_hash": prepared.ordered_quote_ids_hash,
        "slip_fingerprint": slip_fingerprint,
        "sportsbook": "CANARY_SYNTHETIC",
        "american_odds": 150,
        "decimal_odds": 2.5,
        "expires_at": expires_at,
    }


def record(results: list[dict[str, Any]], name: str, expected: Any, actual: Any, passed: bool) -> None:
    results.append({"check": name, "expected": expected, "actual": actual, "pass": bool(passed)})
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n  expected: {expected}\n  actual:   {actual}")


def verify_read_only(engine: Layer5PersistenceV3) -> dict[str, Any]:
    engine.verify_schema_structure()
    policy = engine.verify_operational_connection()
    conn = engine._get_connection()
    try:
        fk = [tuple(r) for r in conn.execute("PRAGMA foreign_key_check;").fetchall()]
        integrity = [r[0] for r in conn.execute("PRAGMA integrity_check;").fetchall()]
        counts = {
            table: conn.execute(f'SELECT count(*) FROM "{table}";').fetchone()[0]
            for table in (
                "sgp_pricing_artifacts_v3",
                "artifact_quote_members_v3",
                "price_vectors_v3",
                "execution_snapshots_v3",
                "client_requests_v3",
            )
        }
    finally:
        conn.close()
    return {
        "policy": {
            "foreign_keys": int(policy["foreign_keys"]),
            "busy_timeout": int(policy["busy_timeout"]),
            "journal_mode": str(policy["journal_mode"]).lower(),
        },
        "foreign_key_violations": fk,
        "integrity_check": integrity,
        "row_counts": counts,
    }


def synthetic_canary(db_path: Path, iterations: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if iterations < 1:
        raise ValueError("iterations must be >= 1")

    engine = Layer5PersistenceV3(db_path)
    engine.verify_operational_connection()
    engine.verify_schema_structure()

    pre = verify_read_only(engine)
    if any(pre["row_counts"].values()):
        raise RuntimeError(
            "ERR_CANARY_SYNTHETIC_REQUIRES_EMPTY_DEDICATED_DB: "
            "synthetic canary refuses to write into a non-empty database"
        )

    results: list[dict[str, Any]] = []
    artifact = finalize_artifact(canary_content(["CANARY_Q1", "CANARY_Q2"]))
    vectors = vectors_for(artifact)
    now = int(time.time())
    run_id = uuid.uuid4().hex
    issued_price_ids: list[str] = []

    for i in range(iterations):
        request_id = f"CANARY_REQ_{run_id}_{i}"
        execution_quote_id = f"CANARY_EXEC_{run_id}_{i}"
        slip = sha256_text(f"{run_id}:slip:{i}")
        quote = quote_for(
            artifact,
            execution_quote_id=execution_quote_id,
            slip_fingerprint=slip,
            expires_at=now + 600,
        )
        repo = {execution_quote_id: quote}
        context = {"request_id": request_id, "slip_fingerprint": slip}

        first = engine.execute_price_issuance(
            artifact, vectors, execution_quote_id, context, repo
        )
        first_ok = first.get("status") == "SUCCESS" and str(first.get("price_id", "")).startswith("prc_")
        record(results, f"issuance_{i + 1}", "SUCCESS + server price_id", first, first_ok)
        if first_ok:
            issued_price_ids.append(first["price_id"])

        repo.clear()
        replay = engine.execute_price_issuance(
            artifact, vectors, execution_quote_id, context, repo
        )
        replay_ok = (
            replay.get("status") == "IDEMPOTENT_REPLAY"
            and replay.get("price_id") == first.get("price_id")
        )
        record(results, f"replay_after_repo_eviction_{i + 1}", first.get("price_id"), replay, replay_ok)

    # Same request, changed structural semantics must fail.
    conflict_req = f"CANARY_REQ_{run_id}_0"
    conflict_exec = f"CANARY_EXEC_{run_id}_0"
    conflict_slip = sha256_text(f"{run_id}:changed-slip")
    try:
        engine.execute_price_issuance(
            artifact,
            vectors,
            conflict_exec,
            {"request_id": conflict_req, "slip_fingerprint": conflict_slip},
            {},
        )
        conflict_actual = "UNEXPECTED_ACCEPT"
        conflict_ok = False
    except Layer5Error as exc:
        conflict_actual = str(exc)
        conflict_ok = conflict_actual.startswith("ERR_IDEMPOTENCY_KEY_REUSED")
    record(results, "idempotency_conflict", "ERR_IDEMPOTENCY_KEY_REUSED", conflict_actual, conflict_ok)

    # Expired authoritative quote must fail before executable persistence.
    expired_artifact = finalize_artifact(canary_content(["CANARY_EXPIRED_Q1", "CANARY_EXPIRED_Q2"]))
    expired_vectors = vectors_for(expired_artifact)
    expired_slip = sha256_text(f"{run_id}:expired-slip")
    expired_exec = f"CANARY_EXPIRED_EXEC_{run_id}"
    expired_quote = quote_for(
        expired_artifact,
        execution_quote_id=expired_exec,
        slip_fingerprint=expired_slip,
        expires_at=now - 1,
    )
    try:
        engine.execute_price_issuance(
            expired_artifact,
            expired_vectors,
            expired_exec,
            {"request_id": f"CANARY_EXPIRED_REQ_{run_id}", "slip_fingerprint": expired_slip},
            {expired_exec: expired_quote},
        )
        expired_actual = "UNEXPECTED_ACCEPT"
        expired_ok = False
    except Layer5Error as exc:
        expired_actual = str(exc)
        expired_ok = expired_actual.startswith("ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED")
    record(results, "expired_quote_rejected", "ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED", expired_actual, expired_ok)

    # Persist an ineligible artifact through the audit path, then prove direct SQL
    # cannot create an executable snapshot for it.
    audit_content = canary_content(["CANARY_AUDIT_Q1", "CANARY_AUDIT_Q2"])
    audit_content["positive_pair_count"] = 10
    audit_content["tail_resolution_satisfied"] = False
    audit_content["price_eligible"] = False
    audit_content["final_joint_probability"] = None
    audit_content["resolution_status"] = "INSUFFICIENT_TAIL_RESOLUTION"
    audit_artifact = finalize_artifact(audit_content)
    audit_vectors = vectors_for(audit_artifact)
    audit_result = engine.execute_price_issuance(
        audit_artifact,
        audit_vectors,
        f"CANARY_UNUSED_AUDIT_EXEC_{run_id}",
        {"request_id": f"CANARY_AUDIT_REQ_{run_id}", "slip_fingerprint": sha256_text(run_id + ":audit")},
        None,
    )
    record(results, "audit_only_path", "AUDIT_ONLY_COMMITTED", audit_result, audit_result.get("status") == "AUDIT_ONLY_COMMITTED")

    prepared_audit = prepare_artifact(audit_artifact)
    conn = engine._get_connection()
    try:
        try:
            conn.execute("BEGIN IMMEDIATE;")
            conn.execute(
                """
                INSERT INTO execution_snapshots_v3 (
                    execution_quote_id, pricing_artifact_hash, ordered_quote_ids_hash,
                    sportsbook, slip_fingerprint, american_odds, decimal_odds,
                    expires_at, canonical_payload, quote_hash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (
                    f"CANARY_ILLEGAL_EXEC_{run_id}",
                    prepared_audit.pricing_artifact_hash,
                    prepared_audit.ordered_quote_ids_hash,
                    "CANARY_SYNTHETIC",
                    sha256_text(run_id + ":illegal"),
                    150,
                    2.5,
                    now + 600,
                    "{}",
                    "a" * 64,
                ),
            )
            conn.execute("COMMIT;")
            authority_actual = "UNEXPECTED_ACCEPT"
            authority_ok = False
        except sqlite3.IntegrityError as exc:
            try:
                conn.execute("ROLLBACK;")
            except sqlite3.Error:
                pass
            authority_actual = str(exc)
            authority_ok = "ERR_SGP_SNAPSHOT_AUTHORITY_FAILED" in authority_actual
    finally:
        conn.close()
    record(results, "direct_sql_ineligible_snapshot_rejected", "ERR_SGP_SNAPSHOT_AUTHORITY_FAILED", authority_actual, authority_ok)

    # Immutable history must still reject mutation after canary writes.
    conn = engine._get_connection()
    try:
        try:
            conn.execute(
                "UPDATE sgp_pricing_artifacts_v3 SET resolution_status='PRECISION_LOW' WHERE pricing_artifact_hash=?;",
                (prepare_artifact(artifact).pricing_artifact_hash,),
            )
            immutable_actual = "UNEXPECTED_UPDATE"
            immutable_ok = False
        except sqlite3.IntegrityError as exc:
            immutable_actual = str(exc)
            immutable_ok = "ERR_SGP_IMMUTABLE_TABLE" in immutable_actual
    finally:
        conn.close()
    record(results, "immutable_history_enforced", "ERR_SGP_IMMUTABLE_TABLE", immutable_actual, immutable_ok)

    post = verify_read_only(engine)
    post_ok = not post["foreign_key_violations"] and post["integrity_check"] == ["ok"]
    record(results, "post_canary_integrity", "foreign_key_check clean + integrity ok", post, post_ok)

    expected_counts = {
        "client_requests_v3": iterations,
        "execution_snapshots_v3": iterations,
        "sgp_pricing_artifacts_v3": 2,  # eligible shared artifact + ineligible audit artifact
        "artifact_quote_members_v3": 4,
        "price_vectors_v3": 4,
    }
    count_ok = post["row_counts"] == expected_counts
    record(results, "synthetic_canary_row_accounting", expected_counts, post["row_counts"], count_ok)

    metadata = {
        "mode": "synthetic_isolated",
        "iterations": iterations,
        "run_id": run_id,
        "issued_price_ids": issued_price_ids,
        "pre_state": pre,
        "post_state": post,
    }
    return results, metadata


def observe_only(db_path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    engine = Layer5PersistenceV3(db_path)
    state = verify_read_only(engine)
    results: list[dict[str, Any]] = []
    record(results, "operational_foreign_keys", 1, state["policy"]["foreign_keys"], state["policy"]["foreign_keys"] == 1)
    record(results, "operational_busy_timeout", ">=5000", state["policy"]["busy_timeout"], state["policy"]["busy_timeout"] >= 5000)
    record(results, "operational_wal", "wal", state["policy"]["journal_mode"], state["policy"]["journal_mode"] == "wal")
    record(results, "foreign_key_check", [], state["foreign_key_violations"], not state["foreign_key_violations"])
    record(results, "integrity_check", ["ok"], state["integrity_check"], state["integrity_check"] == ["ok"])
    return results, {"mode": "observe_only", "state": state}


def main() -> int:
    parser = argparse.ArgumentParser(description="Layer-5 V3 controlled canary harness.")
    parser.add_argument("--db", required=True, help="V3 SQLite database path.")
    parser.add_argument(
        "--mode",
        choices=("synthetic", "observe"),
        default="observe",
        help="observe is read-only; synthetic writes test records and requires an empty dedicated canary DB.",
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=5,
        help="Synthetic issuance/replay iterations. This is a harness setting, not a Layer-5 pricing threshold.",
    )
    parser.add_argument("--report", default=None, help="Optional JSON report path.")
    args = parser.parse_args()

    db_path = Path(args.db).resolve()
    report_path = Path(args.report).resolve() if args.report else db_path.with_suffix(db_path.suffix + f".{args.mode}-canary-report.json")
    report: dict[str, Any] = {
        "report_type": "LAYER5_V3_CANARY",
        "started_at_utc": now_utc(),
        "database_path": str(db_path),
        "mode": args.mode,
        "status": "RUNNING",
    }

    print("==============================================================================")
    print(f"LAYER-5 V3 CANARY — {args.mode.upper()}")
    print("==============================================================================")
    print(f"Database: {db_path}")

    if not db_path.is_file():
        report["status"] = "FAIL"
        report["error"] = "ERR_CANARY_DATABASE_NOT_FOUND"
        report["completed_at_utc"] = now_utc()
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print("❌ ERR_CANARY_DATABASE_NOT_FOUND")
        return 1

    try:
        if args.mode == "synthetic":
            results, metadata = synthetic_canary(db_path, args.iterations)
        else:
            results, metadata = observe_only(db_path)
        passed = all(item["pass"] for item in results)
        report.update({
            "status": "PASS" if passed else "FAIL",
            "completed_at_utc": now_utc(),
            "results": results,
            "metadata": metadata,
        })
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print("\n" + ("✅ CANARY: PASS" if passed else "❌ CANARY: FAIL"))
        print(f"Checks: {sum(1 for x in results if x['pass'])}/{len(results)}")
        print(f"Report: {report_path}")
        return 0 if passed else 1
    except Exception as exc:
        report.update({
            "status": "FAIL",
            "completed_at_utc": now_utc(),
            "error": f"{type(exc).__name__}: {exc}",
        })
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print(f"\n❌ CANARY: FAIL\n{type(exc).__name__}: {exc}")
        print(f"Report: {report_path}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

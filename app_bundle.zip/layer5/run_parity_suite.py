from __future__ import annotations

import copy
import json
import sqlite3
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from sgp_layer5_v3 import (
    Layer5Error,
    Layer5PersistenceV3,
    MAX_ABS_STD_ERROR,
    MAX_REL_STD_ERROR,
    MIN_POSITIVE_PAIRS_FOR_PRICE,
    calculate_sha256,
    canonical_json_stringify,
    finalize_artifact,
    prepare_artifact,
)

ROOT = Path(__file__).resolve().parent
RESULTS: list[dict[str, Any]] = []


def record(label: str, expected: Any, actual: Any, passed: bool) -> None:
    RESULTS.append({"fixture": label, "expected": expected, "actual": actual, "pass": bool(passed)})
    marker = "PASS" if passed else "FAIL"
    print(f"[{marker}] {label}\n  expected: {expected}\n  actual:   {actual}")


def valid_content(ordered_quotes: list[str] | None = None) -> dict[str, Any]:
    ordered_quotes = list(ordered_quotes or ["Q1", "Q2"])
    dimension = len(ordered_quotes)
    return {
        "artifact_schema_version": "SGP_PROV_V1",
        "simulation_engine_version": "SGP_MC_V1",
        "simulation_engine_hash": "1" * 64,
        "prng_algorithm": "SFC32",
        "prng_policy_version": "SFC32_POLICY_V1",
        "model_version": "MODEL_V1",
        "marginal_artifact_hash": "2" * 64,
        "ordered_leg_ids": [f"LEG_{idx+1}" for idx in range(dimension)],
        "ordered_quote_ids": ordered_quotes,
        "matrix_dimension": dimension,
        "matrix_artifact_hash": "3" * 64,
        "cholesky_factor_hash": "4" * 64,
        "matrix_serialization_version": "MAT_REPACK_V1",
        "simulation_seed": "0123456789abcdef0123456789abcdef",
        "thresholds": [0.25 + idx * 0.1 for idx in range(dimension)],
        "replay_input_hash": "5" * 64,
        "min_samples": 100000,
        "max_samples": 500000,
        "target_standard_error": 0.0005,
        "min_positive_pairs_for_price": 50,
        "batch_pairs": 5000,
        "samples_evaluated": 100000,
        "pair_count": 50000,
        "positive_pair_count": 100,
        "total_hits": 20000,
        "raw_pair_standard_error": 0.0004,
        "relative_standard_error": 0.02,
        "precision_satisfied": True,
        "tail_resolution_satisfied": True,
        "stopped_early": False,
        "empirical_probability": 0.20,
        "final_joint_probability": 0.20,
        "price_eligible": True,
        "resolution_status": "VERIFIED",
    }


def vectors_for(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "vector_id": f"VEC_{idx+1}",
            "quote_id": quote_id,
            "data": {"quote_id": quote_id, "marginal_probability": 0.55 + idx * 0.01},
        }
        for idx, quote_id in enumerate(artifact["ordered_quote_ids"])
    ]


def quote_for(artifact: dict[str, Any], *, execution_quote_id: str = "EXEC_Q1", slip: str = "a" * 64, expires_at: int = 2_000_000_000) -> dict[str, Any]:
    prepared = prepare_artifact(artifact)
    return {
        "execution_quote_id": execution_quote_id,
        "pricing_artifact_hash": prepared.pricing_artifact_hash,
        "ordered_quote_ids_hash": prepared.ordered_quote_ids_hash,
        "slip_fingerprint": slip,
        "sportsbook": "DraftKings",
        "american_odds": 150,
        "decimal_odds": 2.5,
        "expires_at": expires_at,
    }


def expect_layer5_error(fn, expected_prefix: str) -> str:
    try:
        fn()
    except Layer5Error as exc:
        actual = str(exc)
        if not actual.startswith(expected_prefix):
            raise AssertionError(f"expected {expected_prefix}, got {actual}") from exc
        return actual
    raise AssertionError(f"expected Layer5Error {expected_prefix}")


def eligibility_negative_fixtures() -> list[tuple[str, dict[str, Any], str]]:
    base = valid_content()
    fixtures: list[tuple[str, dict[str, Any], str]] = []

    x = copy.deepcopy(base)
    x["raw_pair_standard_error"] = MAX_ABS_STD_ERROR + 0.00001
    fixtures.append(("abs_se_ceiling", x, "ERR_SGP_PRECISION_STATE_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["relative_standard_error"] = MAX_REL_STD_ERROR + 0.01
    fixtures.append(("relative_se_ceiling", x, "ERR_SGP_PRECISION_STATE_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["target_standard_error"] = 0.0003
    fixtures.append(("requested_se_target", x, "ERR_SGP_PRECISION_STATE_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["positive_pair_count"] = MIN_POSITIVE_PAIRS_FOR_PRICE - 1
    fixtures.append(("positive_tail_floor", x, "ERR_SGP_TAIL_STATE_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["samples_evaluated"] = 99998
    x["pair_count"] = 49999
    fixtures.append(("minimum_sample_floor", x, "ERR_SGP_SAMPLES_EVALUATED_INVALID"))

    x = copy.deepcopy(base)
    x["pair_count"] = 49999
    fixtures.append(("pair_count_parity", x, "ERR_SGP_PAIR_COUNT_INVALID"))

    x = copy.deepcopy(base)
    x["final_joint_probability"] = 1.0
    fixtures.append(("joint_probability_domain", x, "ERR_SGP_FINAL_JOINT_PROBABILITY_INVALID"))

    x = copy.deepcopy(base)
    x["resolution_status"] = "PRECISION_LOW"
    fixtures.append(("eligible_status_consistency", x, "ERR_SGP_RESOLUTION_STATUS_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["precision_satisfied"] = False
    fixtures.append(("precision_flag_derivation", x, "ERR_SGP_PRECISION_STATE_CONTRADICTION"))

    x = copy.deepcopy(base)
    x["tail_resolution_satisfied"] = False
    fixtures.append(("tail_flag_derivation", x, "ERR_SGP_TAIL_STATE_CONTRADICTION"))

    return fixtures


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="layer5-v3-parity-") as tmp:
        db_path = Path(tmp) / "layer5.sqlite"

        # A. Schema initialization.
        try:
            engine = Layer5PersistenceV3.bootstrap(db_path)
            actual = "schema initialized"
            passed = True
        except Exception as exc:
            actual = f"{type(exc).__name__}: {exc}"
            passed = False
            engine = None
        record("A schema initialization succeeds", "schema initialized", actual, passed)
        if not passed:
            Path(ROOT / "parity_results.json").write_text(json.dumps(RESULTS, indent=2), encoding="utf-8")
            return 1
        assert engine is not None

        # B. FK violation fails on a newly opened operational connection.
        conn = engine._get_connection()
        try:
            try:
                conn.execute("BEGIN IMMEDIATE;")
                conn.execute(
                    "INSERT INTO price_vectors_v3 (vector_id, pricing_artifact_hash, vector_index, quote_id, vector_data) VALUES ('VFK', ?, 0, 'QX', '{}');",
                    ("f" * 64,),
                )
                conn.execute("COMMIT;")
                actual = "unexpected insert success"
                passed = False
            except sqlite3.IntegrityError as exc:
                try:
                    conn.execute("ROLLBACK;")
                except sqlite3.Error:
                    pass
                actual = str(exc)
                passed = "FOREIGN KEY constraint failed" in actual
        finally:
            conn.close()
        record("B FK violation fails on new operational connection", "FOREIGN KEY constraint failed", actual, passed)

        # C/D. Connection policy readbacks.
        policy = engine.verify_operational_connection()
        record("C busy_timeout configured on new connection", ">=5000", policy["busy_timeout"], int(policy["busy_timeout"]) >= 5000)
        record("D WAL bootstrapped and later verified", "wal", str(policy["journal_mode"]).lower(), str(policy["journal_mode"]).lower() == "wal")

        # E. Ordered identity is sequence-sensitive.
        art_q12 = finalize_artifact(valid_content(["Q1", "Q2"]))
        art_q21 = finalize_artifact(valid_content(["Q2", "Q1"]))
        actual = {"Q1,Q2": art_q12["pricing_artifact_hash"], "Q2,Q1": art_q21["pricing_artifact_hash"]}
        record("E ordered quote identity remains distinct", "different hashes", actual, actual["Q1,Q2"] != actual["Q2,Q1"])

        # F. Same ID + same canonical semantics is idempotent.
        vecs = vectors_for(art_q12)
        h1 = engine.register_pricing_artifact(art_q12, vecs)
        h2 = engine.register_pricing_artifact(copy.deepcopy(art_q12), copy.deepcopy(vecs))
        record("F same artifact ID + same semantics is idempotent", h1, h2, h1 == h2)

        # G. Same ID + different semantics hard-fails as identity collision.
        divergent = copy.deepcopy(art_q12)
        divergent["model_version"] = "MODEL_DIFFERENT"
        collision_actual = expect_layer5_error(
            lambda: engine.register_pricing_artifact(divergent, vecs),
            "ERR_PRICING_ARTIFACT_IDENTITY_COLLISION",
        )
        record("G same artifact ID + different semantics hard-fails", "ERR_PRICING_ARTIFACT_IDENTITY_COLLISION", collision_actual, collision_actual.startswith("ERR_PRICING_ARTIFACT_IDENTITY_COLLISION"))

        # H. Returned provenance identity equals durable identity.
        stored = engine.fetch_artifact(h1)
        durable = None if stored is None else stored["pricing_artifact_hash"]
        record("H returned provenance hash equals persisted hash", h1, durable, durable == h1)

        # I/J. Immutable history.
        conn = engine._get_connection()
        try:
            try:
                conn.execute("UPDATE sgp_pricing_artifacts_v3 SET resolution_status='PRECISION_LOW' WHERE pricing_artifact_hash=?;", (h1,))
                update_actual, update_pass = "unexpected update success", False
            except sqlite3.IntegrityError as exc:
                update_actual, update_pass = str(exc), "ERR_SGP_IMMUTABLE_TABLE" in str(exc)

            try:
                conn.execute("DELETE FROM sgp_pricing_artifacts_v3 WHERE pricing_artifact_hash=?;", (h1,))
                delete_actual, delete_pass = "unexpected delete success", False
            except sqlite3.IntegrityError as exc:
                delete_actual, delete_pass = str(exc), "ERR_SGP_IMMUTABLE_TABLE" in str(exc)
        finally:
            conn.close()
        record("I UPDATE immutable record fails", "ERR_SGP_IMMUTABLE_TABLE", update_actual, update_pass)
        record("J DELETE immutable record fails", "ERR_SGP_IMMUTABLE_TABLE", delete_actual, delete_pass)

        # K. Frozen eligibility negative fixtures.
        negative_actual: dict[str, str] = {}
        negative_pass = True
        for name, mutation, expected_error in eligibility_negative_fixtures():
            candidate = finalize_artifact(mutation)
            try:
                prepare_artifact(candidate)
                negative_actual[name] = "UNEXPECTED_ACCEPT"
                negative_pass = False
            except Layer5Error as exc:
                negative_actual[name] = str(exc)
                if not str(exc).startswith(expected_error):
                    negative_pass = False
        record("K frozen eligibility-negative fixtures rejected", "all negative fixtures rejected by exact frozen gates", negative_actual, negative_pass)

        # L. Canonical-equivalent object key order is equivalent where V3 defines it so.
        left = {"z": 3, "a": 1, "nested": {"y": 2, "b": True}}
        right = {"nested": {"b": True, "y": 2}, "a": 1, "z": 3}
        left_bytes = canonical_json_stringify(left)
        right_bytes = canonical_json_stringify(right)
        actual = {"left": left_bytes, "right": right_bytes, "hash_left": calculate_sha256(left_bytes), "hash_right": calculate_sha256(right_bytes)}
        record("L canonical-equivalent object inputs produce same bytes/hash", "identical canonical text and SHA-256", actual, left_bytes == right_bytes and actual["hash_left"] == actual["hash_right"])

        # M. Node/V3 frozen canonical fixtures are byte-equivalent.
        node_out = json.loads(subprocess.check_output(["node", str(ROOT / "node_canonical_fixture.js")], text=True))
        golden_obj = {
            "matrix": [[1, 0.5], [0.5, 1]],
            "matrix_serialization_version": "MAT_REPACK_V1",
            "ordered_leg_ids": ["LEG_NFL_101_WIN", "LEG_NFL_202_OVER"],
        }
        expected_golden = '{"matrix":[[1,0.5],[0.5,1]],"matrix_serialization_version":"MAT_REPACK_V1","ordered_leg_ids":["LEG_NFL_101_WIN","LEG_NFL_202_OVER"]}'
        expected_golden_hash = "b7ffe38bdb2d103c24c8cf1a3fa11ce9a94f4cb4b256a77b98fa2b2e4093fe99"
        py_golden = canonical_json_stringify(golden_obj)
        py_fixture_values = {
            "golden_matrix": golden_obj,
            "key_order": {"z": 1, "a": 2, "nested": {"y": True, "b": None}},
            "number_boundaries": {"a": 0.000001, "b": 1e-7, "c": 1e20, "d": 1e21, "e": -0.0},
        }
        mismatch = {}
        for name, value in py_fixture_values.items():
            py_text = canonical_json_stringify(value)
            py_hash = calculate_sha256(py_text)
            if py_text != node_out[name]["canonical"] or py_hash != node_out[name]["sha256"]:
                mismatch[name] = {"python": [py_text, py_hash], "node": [node_out[name]["canonical"], node_out[name]["sha256"]]}
        m_pass = not mismatch and py_golden == expected_golden and calculate_sha256(py_golden) == expected_golden_hash
        m_actual = {
            "golden_canonical": py_golden,
            "golden_sha256": calculate_sha256(py_golden),
            "node_fixture_mismatches": mismatch,
        }
        record("M Node/V3 canonical fixtures byte-equivalent", {"golden": expected_golden, "sha256": expected_golden_hash, "mismatches": {}}, m_actual, m_pass)

        # Use a separate fresh DB for commercial issuance to avoid the prior artifact-only registration state affecting clarity.
        issue_db = Path(tmp) / "issuance.sqlite"
        issue_engine = Layer5PersistenceV3.bootstrap(issue_db)
        issue_artifact = finalize_artifact(valid_content())
        issue_vectors = vectors_for(issue_artifact)
        slip = "a" * 64
        quote = quote_for(issue_artifact, slip=slip)
        repo = {quote["execution_quote_id"]: quote}
        request_context = {"request_id": "REQ-1", "slip_fingerprint": slip}

        first = issue_engine.execute_price_issuance(issue_artifact, issue_vectors, quote["execution_quote_id"], request_context, repo)
        first_price = first["price_id"]
        # Mutate/remove repository state. Durable replay must not consult it.
        repo.clear()
        replay = issue_engine.execute_price_issuance(issue_artifact, issue_vectors, quote["execution_quote_id"], request_context, repo)
        replay_pass = first["status"] == "SUCCESS" and replay["status"] == "IDEMPOTENT_REPLAY" and replay["price_id"] == first_price
        # Same request ID but changed structural semantics must conflict.
        conflict_ctx = {"request_id": "REQ-1", "slip_fingerprint": "b" * 64}
        conflict_actual = expect_layer5_error(
            lambda: issue_engine.execute_price_issuance(issue_artifact, issue_vectors, quote["execution_quote_id"], conflict_ctx, repo),
            "ERR_IDEMPOTENCY_KEY_REUSED",
        )
        replay_pass = replay_pass and conflict_actual.startswith("ERR_IDEMPOTENCY_KEY_REUSED")
        record("N replay/idempotency behavior matches V3", {"replay_price": first_price, "changed_semantics": "ERR_IDEMPOTENCY_KEY_REUSED"}, {"first": first, "replay": replay, "changed_semantics": conflict_actual}, replay_pass)

        # O. Expired state cannot issue.
        expired_artifact = finalize_artifact(valid_content(["QE1", "QE2"]))
        expired_vectors = vectors_for(expired_artifact)
        expired_slip = "c" * 64
        expired_quote = quote_for(expired_artifact, execution_quote_id="EXEC_EXPIRED", slip=expired_slip, expires_at=int(time.time()) - 1)
        expired_repo = {"EXEC_EXPIRED": expired_quote}
        expired_actual = expect_layer5_error(
            lambda: issue_engine.execute_price_issuance(
                expired_artifact,
                expired_vectors,
                "EXEC_EXPIRED",
                {"request_id": "REQ-EXPIRED", "slip_fingerprint": expired_slip},
                expired_repo,
            ),
            "ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED",
        )
        record("O expired pricing state cannot issue live price", "ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED", expired_actual, expired_actual.startswith("ERR_SGP_PERSISTENCE_QUOTE_SNAPSHOT_EXPIRED"))

        # P. Concurrent artifact registration never splits identity.
        conc_db = Path(tmp) / "concurrency.sqlite"
        conc_engine = Layer5PersistenceV3.bootstrap(conc_db)
        conc_artifact = finalize_artifact(valid_content(["QC1", "QC2"]))
        conc_vectors = vectors_for(conc_artifact)
        outputs: list[str] = []
        errors: list[str] = []
        lock = threading.Lock()
        barrier = threading.Barrier(8)

        def worker() -> None:
            try:
                barrier.wait()
                value = conc_engine.register_pricing_artifact(copy.deepcopy(conc_artifact), copy.deepcopy(conc_vectors))
                with lock:
                    outputs.append(value)
            except Exception as exc:
                with lock:
                    errors.append(f"{type(exc).__name__}: {exc}")

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        conn = conc_engine._get_connection()
        try:
            rows = conn.execute("SELECT pricing_artifact_hash, canonical_payload FROM sgp_pricing_artifacts_v3;").fetchall()
        finally:
            conn.close()
        p_actual = {"returns": outputs, "errors": errors, "durable_row_count": len(rows), "durable_hashes": [r["pricing_artifact_hash"] for r in rows]}
        p_pass = not errors and len(outputs) == 8 and len(set(outputs)) == 1 and len(rows) == 1 and rows[0]["pricing_artifact_hash"] == outputs[0]
        record("P concurrent artifact registration has no split identity", "8 identical returns, 1 durable artifact row, 0 errors", p_actual, p_pass)

        # Extra: server-generated price ID evidence.
        server_id_pass = first_price.startswith("prc_") and first_price != "REQ-1"
        record("Q price_id is generated by trusted issuance path", "prc_<uuid> generated server-side", first_price, server_id_pass)

        # Extra: audit-only ineligible persistence is repository-independent.
        audit_content = valid_content(["QA1", "QA2"])
        audit_content["positive_pair_count"] = 10
        audit_content["tail_resolution_satisfied"] = False
        audit_content["price_eligible"] = False
        audit_content["final_joint_probability"] = None
        audit_content["resolution_status"] = "INSUFFICIENT_TAIL_RESOLUTION"
        audit_artifact = finalize_artifact(audit_content)
        audit_vectors = vectors_for(audit_artifact)
        audit_out = issue_engine.execute_price_issuance(
            audit_artifact,
            audit_vectors,
            "UNUSED_AUDIT_QUOTE",
            {"request_id": "REQ-AUDIT", "slip_fingerprint": "d" * 64},
            None,
        )
        record("R audit-only ineligible persistence bypasses quote repository", "AUDIT_ONLY_COMMITTED", audit_out, audit_out["status"] == "AUDIT_ONLY_COMMITTED")

    results_path = ROOT / "parity_results.json"
    results_path.write_text(json.dumps(RESULTS, indent=2, sort_keys=True), encoding="utf-8")
    passed_count = sum(1 for item in RESULTS if item["pass"])
    print(f"\nSUMMARY: {passed_count}/{len(RESULTS)} fixtures passed")
    return 0 if passed_count == len(RESULTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())

const crypto = require('crypto');

function canonicalJsonStringify(value) {
  if (value === null) return 'null';
  if (value === true) return 'true';
  if (value === false) return 'false';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('non-finite');
    return JSON.stringify(value);
  }
  if (typeof value === 'string') return JSON.stringify(value);
  if (Array.isArray(value)) {
    return '[' + value.map(canonicalJsonStringify).join(',') + ']';
  }
  if (typeof value === 'object') {
    const keys = Object.keys(value).sort();
    return '{' + keys.map(k => JSON.stringify(k) + ':' + canonicalJsonStringify(value[k])).join(',') + '}';
  }
  throw new TypeError('unsupported');
}

const fixtures = {
  golden_matrix: {
    matrix: [[1,0.5],[0.5,1]],
    matrix_serialization_version: 'MAT_REPACK_V1',
    ordered_leg_ids: ['LEG_NFL_101_WIN','LEG_NFL_202_OVER']
  },
  key_order: { z: 1, a: 2, nested: { y: true, b: null } },
  number_boundaries: { a: 0.000001, b: 1e-7, c: 1e20, d: 1e21, e: -0 }
};

const out = {};
for (const [name, value] of Object.entries(fixtures)) {
  const canonical = canonicalJsonStringify(value);
  out[name] = {
    canonical,
    sha256: crypto.createHash('sha256').update(canonical).digest('hex')
  };
}
process.stdout.write(JSON.stringify(out));

# Deployment Status — Automatic Prop Scanner Release Candidate

## VERIFIED in this package build

- Multi-sport registry remains active for NFL, CFB/NCAAF, MLB, NBA, WNBA, NCAAB, and NHL.
- Automatic `GET /api/sports/:sport/scan` route added.
- The Odds API player-prop board is normalized across books, lines, prices, and update times.
- Scanner performs cross-book line comparison and paired no-vig market support when both sides are available.
- BALLDONTLIE recent-game enrichment is implemented for NFL, CFB/NCAAF, MLB, NBA, WNBA, and NCAAB.
- Exact-line Last-5 and Last-10 hit-rate evidence is calculated.
- 0.6×Last-5 + 0.4×Last-10 recent-form projection is used as a transparent ranking input, not a calibrated probability.
- Vs-current-opponent history is used when the stats feed exposes sufficient team/game identity.
- Tiny statistical samples cannot promote a candidate to CORE/STRONG.
- Market-only candidates cannot be promoted above MARKET_WATCH.
- Inherently volatile scorer markets are never promoted to CORE.
- Scanner can return PASS instead of forcing a recommendation.
- API usage guardrails cap the event time horizon, number of event prop calls, and number of statistical enrichments.
- End-to-end scanner integration is tested with deterministic mock market and stats providers.
- Original Python Layer-5 V3 baseline remains preserved.
- Global Layer-5 pricing still defaults to OFF.
- Layer-5 18-fixture regression, fresh bootstrap, and isolated synthetic canary remain passing.

## UNVERIFIED in this workspace

- Real live calls to The Odds API using the user's production key.
- Real live calls to BALLDONTLIE using the user's account/tier.
- Real-provider player-name resolution across every roster/player edge case.
- Genuine application Layer-5 production canary traffic.

## Required on deployment host

1. Add `ODDS_API_KEY` for live prop discovery.
2. Add `BALLDONTLIE_API_KEY` if recent-game enrichment is desired.
3. Start the app and use **Scan Props** on a small slate first.
4. Review provider quota/latency and tune `PROP_MAX_EVENTS`, `PROP_EVENT_HORIZON_HOURS`, and `SCAN_ENRICH_LIMIT` if needed.
5. Keep `LAYER5_PRICING_ENABLED=false` until genuine Layer-5 application canary acceptance.

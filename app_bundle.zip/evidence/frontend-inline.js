
const state={sport:'nfl',sports:[],mode:'demo',slip:[],liveConfigured:false,statsConfigured:false};
const $=s=>document.querySelector(s);
const fmtOdds=o=>Number(o)>0?`+${o}`:`${o}`;
const toDecimal=o=>Number(o)>0?1+Number(o)/100:1+100/Math.abs(Number(o));
const future=(hours)=>new Date(Date.now()+hours*3600e3).toISOString();
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

const demo={
 nfl:[{gameId:'demo-nfl-1',commenceTime:future(28),awayTeam:'Buffalo Bills',homeTeam:'Kansas City Chiefs',props:[
  {player:'Josh Allen',playerId:'josh-allen',market:'player_pass_yds',label:'Pass Yards',line:252.5,book:'Demo',outcomes:{over:-112,under:-108}},
  {player:'Patrick Mahomes',playerId:'patrick-mahomes',market:'player_pass_completions',label:'Pass Completions',line:24.5,book:'Demo',outcomes:{over:-115,under:-105}},
  {player:'James Cook',playerId:'james-cook',market:'player_rush_yds',label:'Rush Yards',line:68.5,book:'Demo',outcomes:{over:-110,under:-110}}]}],
 cfb:[{gameId:'demo-cfb-1',commenceTime:future(34),awayTeam:'Texas',homeTeam:'Georgia',props:[
  {player:'QB Example',playerId:'cfb-qb-1',market:'player_pass_yds',label:'Pass Yards',line:244.5,book:'Demo',outcomes:{over:-110,under:-110}},
  {player:'RB Example',playerId:'cfb-rb-1',market:'player_rush_attempts',label:'Rush Attempts',line:16.5,book:'Demo',outcomes:{over:-105,under:-115}}]}],
 mlb:[{gameId:'demo-mlb-1',commenceTime:future(8),awayTeam:'Yankees',homeTeam:'Dodgers',props:[
  {player:'Aaron Judge',playerId:'aaron-judge',market:'batter_total_bases',label:'Total Bases',line:1.5,book:'Demo',outcomes:{over:115,under:-145}},
  {player:'Mookie Betts',playerId:'mookie-betts',market:'batter_singles',label:'Singles',line:.5,book:'Demo',outcomes:{over:-120,under:-110}},
  {player:'Starter Example',playerId:'starter-example',market:'pitcher_strikeouts',label:'Pitcher Strikeouts',line:5.5,book:'Demo',outcomes:{over:-105,under:-125}}]}],
 nba:[{gameId:'demo-nba-1',commenceTime:future(50),awayTeam:'Lakers',homeTeam:'Warriors',props:[
  {player:'Guard Example',playerId:'nba-guard',market:'player_points',label:'Points',line:26.5,book:'Demo',outcomes:{over:-110,under:-110}},
  {player:'Center Example',playerId:'nba-center',market:'player_rebounds',label:'Rebounds',line:10.5,book:'Demo',outcomes:{over:-105,under:-115}}]}],
 wnba:[{gameId:'demo-wnba-1',commenceTime:future(24),awayTeam:'Liberty',homeTeam:'Aces',props:[
  {player:'Guard Example',playerId:'wnba-guard',market:'player_assists',label:'Assists',line:6.5,book:'Demo',outcomes:{over:100,under:-130}},
  {player:'Forward Example',playerId:'wnba-forward',market:'player_rebounds',label:'Rebounds',line:7.5,book:'Demo',outcomes:{over:-115,under:-105}}]}],
 ncaab:[{gameId:'demo-ncaab-1',commenceTime:future(75),awayTeam:'Duke',homeTeam:'Kansas',props:[
  {player:'Wing Example',playerId:'ncaab-wing',market:'player_points',label:'Points',line:17.5,book:'Demo',outcomes:{over:-110,under:-110}}]}],
 nhl:[{gameId:'demo-nhl-1',commenceTime:future(30),awayTeam:'Stars',homeTeam:'Avalanche',props:[
  {player:'Skater Example',playerId:'nhl-skater',market:'player_shots_on_goal',label:'Shots on Goal',line:3.5,book:'Demo',outcomes:{over:105,under:-135}},
  {player:'Goalie Example',playerId:'nhl-goalie',market:'player_total_saves',label:'Goalie Saves',line:27.5,book:'Demo',outcomes:{over:-110,under:-110}}]}]
};

function showError(message){const el=$('#errorBox');el.textContent=message;el.style.display='block'}
function clearError(){$('#errorBox').style.display='none'}
function marketLabel(key){return key.replaceAll('_',' ').replace(/\b\w/g,m=>m.toUpperCase())}

async function boot(){
 try{
  const [sportsRes,healthRes]=await Promise.all([fetch('/api/sports'),fetch('/health')]);
  const sportsData=await sportsRes.json();const health=await healthRes.json();
  state.sports=sportsData.sports||[];state.liveConfigured=Boolean(sportsData.liveOddsConfigured);state.statsConfigured=Boolean(sportsData.statsFeedConfigured);
  $('#appStatus').textContent=`${health.supportedSports.length} sports • clean-start V3`;
  renderSports();renderDemo();checkLayer5();
 }catch(e){showError(`Startup check failed: ${e.message}`);renderDemo()}
}

function renderSports(){
 const root=$('#sports');root.innerHTML='';
 state.sports.forEach(s=>{const b=document.createElement('button');b.className=`sport ${state.sport===s.slug?'active':''}`;b.textContent=s.title;b.onclick=()=>{state.sport=s.slug;renderSports();renderDemo()};root.appendChild(b)});
}

function renderDemo(){state.mode='demo';clearError();$('#modeNote').textContent='Demo mode does not use sportsbook API credits.';renderGames(demo[state.sport]||[],`${state.sport.toUpperCase()} demo board`,'Synthetic display data — not betting advice or a live line.')}

function normalizeLiveProps(payload){
 return (payload.games||[]).map(game=>{
  const props=[];
  Object.entries(game.markets||{}).forEach(([market,players])=>{
   Object.entries(players||{}).forEach(([playerName,player])=>{
    const bookEntry=Object.values(player.books||{})[0];if(!bookEntry)return;
    const offer=(bookEntry.offers||[])[0];if(!offer)return;
    const outcomes={};Object.entries(offer.outcomes||{}).forEach(([side,data])=>{outcomes[side]=data.americanOdds});
    props.push({player:playerName,playerId:`${playerName.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,market,label:marketLabel(market),line:offer.line,book:bookEntry.bookmaker,outcomes});
   });
  });
  return {...game,props};
 });
}

function normalizeFeatured(payload){
 return (payload.games||[]).map(game=>{
  const props=[];
  Object.entries(game.markets||{}).forEach(([market,books])=>{
   const book=Object.values(books||{})[0];if(!book)return;
   (book.outcomes||[]).forEach((outcome,i)=>{
    const player=outcome.name;const point=Number.isFinite(outcome.point)?outcome.point:null;
    props.push({player,playerId:`team-${i}-${player.toLowerCase().replace(/[^a-z0-9]+/g,'-')}`,market,label:marketLabel(market),line:point,book:book.bookmaker,outcomes:{pick:outcome.price}})
   });
  });
  return {...game,props};
 });
}

async function loadLive(kind){
 clearError();if(!state.liveConfigured){return showError('Live Odds API is not configured yet. Add ODDS_API_KEY as a secret on the host; demo mode still works.')}
 const btn=kind==='props'?$('#liveBtn'):$('#featuredBtn');btn.disabled=true;$('#games').innerHTML='<div class="loading">Loading live board…</div>';
 try{
  const endpoint=kind==='props'?`/api/sports/${state.sport}/props`:`/api/sports/${state.sport}/featured`;
  const res=await fetch(endpoint);const payload=await res.json();if(!res.ok)throw new Error(payload.error?.message||`HTTP ${res.status}`);
  state.mode=kind;const games=kind==='props'?normalizeLiveProps(payload):normalizeFeatured(payload);
  $('#modeNote').textContent=`Live ${kind==='props'?'props':'featured markets'} • fetched ${new Date(payload.fetchedAt).toLocaleTimeString()}`;
  renderGames(games,`${payload.sport.title} live ${kind==='props'?'props':'markets'}`,payload.quota?.remaining?`API credits remaining: ${payload.quota.remaining}`:'Live sportsbook feed');
 }catch(e){showError(`Live load failed: ${e.message}`);renderDemo()}finally{btn.disabled=false}
}

function pct(value){return Number.isFinite(Number(value))?`${Math.round(Number(value)*100)}%`:'—'}
function signed(value){const n=Number(value);return Number.isFinite(n)?`${n>0?'+':''}${n}`:'—'}

async function scanProps(){
 clearError();if(!state.liveConfigured){return showError('The automatic scanner needs ODDS_API_KEY. Add it as a host secret first.')}
 const btn=$('#scanBtn');btn.disabled=true;$('#games').innerHTML='<div class="loading">Scanning live props across books and checking evidence…</div>';
 try{
  const res=await fetch(`/api/sports/${state.sport}/scan`);const payload=await res.json();if(!res.ok)throw new Error(payload.error?.message||`HTTP ${res.status}`);
  state.mode='scan';
  const statsActive=Boolean(payload.feeds?.stats?.activeForSport);
  $('#modeNote').textContent=statsActive?'Scanner: market + recent-game stats':'Scanner: market-only (add BALLDONTLIE_API_KEY for recent-game enrichment)';
  renderScan(payload);
 }catch(e){showError(`Prop scan failed: ${e.message}`);renderDemo()}finally{btn.disabled=false}
}

function renderScan(payload){
 const scan=payload.scan||{};const candidates=(scan.candidates||[]).filter(c=>c.classification!=='PASS').slice(0,30);
 $('#boardTitle').textContent=`${payload.sport.title} automatic prop scan`;
 $('#boardMeta').textContent=`${scan.scannedPlayerMarkets||0} player-markets scanned • ${scan.actionableCount||0} non-pass candidates`;
 const root=$('#games');root.innerHTML='';
 const summary=document.createElement('div');summary.className='scan-summary';
 const counts=scan.summary||{};summary.innerHTML=`<span class="chip">CORE ${counts.core||0}</span><span class="chip">STRONG ${counts.strong||0}</span><span class="chip">HIGH VAR ${counts.highVariance||0}</span><span class="chip">MARKET WATCH ${counts.marketWatch||0}</span><span class="chip">WATCH ${counts.watch||0}</span><span class="chip">PASS ${counts.pass||0}</span>`;root.appendChild(summary);
 if(!candidates.length){root.insertAdjacentHTML('beforeend','<div class="empty"><strong>No prop cleared the scanner today.</strong><br><br>That is a valid result — PASS instead of forcing a play.</div>');return}
 candidates.forEach(c=>{
  const card=document.createElement('article');card.className='scan-card';
  const stat=c.statsEvidence||{};const market=c.marketEvidence||{};const cls=String(c.classification||'pass').toLowerCase();
  const recent5=stat.available?pct(stat.last5?.hitRate):'No stats';const recent10=stat.available?pct(stat.last10?.hitRate):'No stats';
  const reasons=(c.reasons||[]).slice(0,4).map(r=>`<li>${esc(r)}</li>`).join('');
  const risks=(c.risks||[]).slice(0,3).map(r=>`<li>${esc(r)}</li>`).join('');
  card.innerHTML=`<div class="scan-head"><div><span class="badge ${cls}">${esc(c.classification)}</span><div class="player" style="margin-top:8px">${esc(c.playerName)}</div><div class="market">${esc(c.matchup)} • ${esc(c.side.toUpperCase())} ${esc(c.line)} ${esc(c.marketLabel)}</div></div><div style="text-align:right"><div class="score">${esc(c.evidenceScore)}</div><div class="meta">evidence score</div></div></div><div class="evidence"><div class="evidence-box"><span class="meta">Best book</span><strong>${esc(market.bestBook||'—')} ${esc(fmtOdds(market.bestAmericanOdds))}</strong></div><div class="evidence-box"><span class="meta">Line vs median</span><strong>${esc(c.line)} vs ${esc(market.consensusLine??'—')}</strong></div><div class="evidence-box"><span class="meta">Last 5</span><strong>${esc(recent5)}</strong></div><div class="evidence-box"><span class="meta">Last 10</span><strong>${esc(recent10)}</strong></div><div class="evidence-box"><span class="meta">Projection</span><strong>${stat.available?esc(stat.projection):'—'}</strong></div><div class="evidence-box"><span class="meta">Data quality</span><strong>${esc(c.dataQuality)}</strong></div></div>${reasons?`<div class="meta"><strong>Why it surfaced</strong></div><ul class="reason-list">${reasons}</ul>`:''}${risks?`<div class="meta" style="margin-top:8px"><strong>Risks</strong></div><ul class="reason-list">${risks}</ul>`:''}<div class="scan-actions"><button class="btn add-scan">Add to Slip</button><span class="data-note">Ranking only — not a calibrated win probability.</span></div>`;
  card.querySelector('.add-scan').onclick=()=>addLeg({id:`scan|${state.sport}|${c.gameId}|${c.playerName}|${c.market}|${c.side}|${c.line}`,sport:state.sport,gameId:c.gameId,kickoffTime:c.commenceTime,playerId:c.playerName.toLowerCase().replace(/[^a-z0-9]+/g,'-'),player:c.playerName,market:c.market,marketLabel:c.marketLabel,side:c.side,line:c.line,odds:Number(market.bestAmericanOdds),book:market.bestBook});
  root.appendChild(card);
 });
 renderSlip();
}

function renderGames(games,title,meta){
 $('#boardTitle').textContent=title;$('#boardMeta').textContent=meta;const root=$('#games');root.innerHTML='';
 if(!games.length){root.innerHTML='<div class="empty">No games are available for this board right now.</div>';return}
 games.forEach(game=>{
  const card=document.createElement('article');card.className='game';const when=new Date(game.commenceTime||future(1));
  card.innerHTML=`<div class="game-head"><div><div class="matchup">${game.matchup||`${game.awayTeam} @ ${game.homeTeam}`}</div><div class="meta">${when.toLocaleString()}</div></div><div class="meta">${game.status&&game.status!=='available'?game.message||game.status:''}</div></div><div class="props"></div>`;
  const props=card.querySelector('.props');
  (game.props||[]).forEach(prop=>props.appendChild(propCard(game,prop)));
  if(!(game.props||[]).length)props.innerHTML='<div class="empty">No requested markets available.</div>';
  root.appendChild(card);
 });
 renderSlip();
}

function propCard(game,prop){
 const el=document.createElement('div');el.className='prop';el.innerHTML=`<div class="prop-top"><div><div class="player">${prop.player}</div><div class="market">${prop.label}${prop.line!=null?` • ${prop.line}`:''}</div></div><div class="book">${prop.book||''}</div></div><div class="outcomes"></div>`;
 const out=el.querySelector('.outcomes');
 Object.entries(prop.outcomes||{}).forEach(([side,odds])=>{if(!Number.isFinite(Number(odds)))return;const id=`${state.sport}|${game.gameId}|${prop.playerId}|${prop.market}|${side}|${prop.line}`;const b=document.createElement('button');b.className=`pick ${state.slip.some(x=>x.id===id)?'selected':''}`;b.innerHTML=`<strong><span>${side[0].toUpperCase()+side.slice(1)}</span><span>${fmtOdds(odds)}</span></strong>`;b.onclick=()=>addLeg({id,sport:state.sport,gameId:game.gameId,kickoffTime:game.commenceTime,playerId:prop.playerId,player:prop.player,market:prop.market,marketLabel:prop.label,side,line:prop.line,odds:Number(odds),book:prop.book});out.appendChild(b)});
 return el;
}

async function addLeg(leg){
 clearError();const candidate=[...state.slip,leg];
 try{const res=await fetch('/api/slip/validate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({legs:candidate})});const data=await res.json();if(!res.ok){const msg=data.errors?.[0]?.message||'Selection failed validation.';return showError(msg)}state.slip=candidate;renderCurrentBoardRefresh();renderSlip()}catch(e){showError(`Slip validation failed: ${e.message}`)}
}
function removeLeg(id){state.slip=state.slip.filter(x=>x.id!==id);renderCurrentBoardRefresh();renderSlip()}
function renderCurrentBoardRefresh(){document.querySelectorAll('.pick').forEach(btn=>btn.classList.remove('selected'));}
function renderSlip(){
 const root=$('#slipList');root.innerHTML='';
 if(!state.slip.length)root.innerHTML='<div class="slip-empty">Select a line to build a cross-sport ticket.</div>';
 state.slip.forEach(leg=>{const el=document.createElement('div');el.className='leg';el.innerHTML=`<div class="leg-top"><strong>${leg.player}</strong><button class="remove">×</button></div><div class="meta">${leg.sport.toUpperCase()} • ${leg.side}${leg.line!=null?` ${leg.line}`:''} ${leg.marketLabel} • ${fmtOdds(leg.odds)}</div><div class="meta">${leg.book||''}</div>`;el.querySelector('.remove').onclick=()=>removeLeg(leg.id);root.appendChild(el)});
 $('#legCount').textContent=state.slip.length;const raw=state.slip.reduce((p,l)=>p*toDecimal(l.odds),1);$('#rawDecimal').textContent=`${raw.toFixed(2)}x`;
}

async function checkLayer5(){
 const gate=$('#layer5Gate');
 try{const res=await fetch('/api/layer5/status');const d=await res.json();let cls='warn',label=d.status;if(d.status==='PASS')cls=d.pricingEnabled?'good':'warn';if(d.status==='FAIL')cls='bad';gate.innerHTML=`<div class="gate-row"><span>Layer‑5 DB</span><strong class="${cls}">${label}</strong></div><div class="gate-row"><span>Global pricing</span><strong class="${d.pricingEnabled?'good':'warn'}">${d.pricingEnabled?'ENABLED':'GATED'}</strong></div><div class="meta" style="margin-top:8px">${d.status==='NOT_INITIALIZED'?'Fresh V3 bootstrap is the next deployment step.':d.status==='PASS'&&!d.pricingEnabled?'Database checks pass; genuine application canary still controls rollout.':'See runtime status before production use.'}</div>`}
 catch(e){gate.innerHTML='<div class="gate-row"><span>Layer‑5</span><strong class="bad">STATUS ERROR</strong></div>'}
}

$('#demoBtn').onclick=renderDemo;$('#liveBtn').onclick=()=>loadLive('props');$('#scanBtn').onclick=scanProps;$('#featuredBtn').onclick=()=>loadLive('featured');boot();

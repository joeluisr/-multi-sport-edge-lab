import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { validateBetSlip } from './src/betSlipValidator.js';
import { analyzePlayerProp } from './src/propAnalyzer.js';
import { FEATURED_MARKETS, getSportConfig, listSports } from './src/sportConfig.js';
import { scanPropBoard } from './src/propScanner.js';
import { enrichPropWithBalldontlie, isBalldontlieConfigured, balldontlieSupportedSports } from './src/balldontlie.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const API_BASE = process.env.ODDS_API_BASE?.trim() || 'https://api.the-odds-api.com/v4';
const REGIONS = process.env.ODDS_API_REGIONS || 'us';
const CONCURRENCY = Math.max(1, Number(process.env.ODDS_API_CONCURRENCY || 4));
const LAYER5_DB_PATH = path.resolve(__dirname, process.env.LAYER5_DB_PATH || './data/production_sgp_v3.db');
const LAYER5_PRICING_ENABLED = String(process.env.LAYER5_PRICING_ENABLED || 'false').toLowerCase() === 'true';
const INDEX_PATH = path.join(__dirname, 'public', 'index.html');
const SCAN_ENRICH_LIMIT = Math.max(0, Number(process.env.SCAN_ENRICH_LIMIT || 12));
const PROP_EVENT_HORIZON_HOURS = Math.max(1, Number(process.env.PROP_EVENT_HORIZON_HOURS || 36));
const PROP_MAX_EVENTS = Math.max(1, Number(process.env.PROP_MAX_EVENTS || 20));

function json(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  });
  res.end(body);
}

function text(res, status, body, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'content-type': contentType,
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  });
  res.end(body);
}

async function readJson(req, maxBytes = 250_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error('Request body too large.'), { statusCode: 413, code: 'REQUEST_TOO_LARGE' });
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Request body must be valid JSON.'), { statusCode: 400, code: 'INVALID_JSON' }); }
}

function getApiKey() {
  const apiKey = process.env.ODDS_API_KEY?.trim();
  if (!apiKey) throw Object.assign(new Error('ODDS_API_KEY is missing. Add it as a host secret before loading live odds.'), { statusCode: 503, code: 'MISSING_API_KEY' });
  return apiKey;
}

async function fetchJson(url) {
  const response = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(15_000) });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : null; } catch { data = raw; }
  if (!response.ok) {
    throw Object.assign(new Error(`The Odds API request failed with HTTP ${response.status}.`), {
      statusCode: 502,
      code: 'ODDS_API_REQUEST_FAILED',
      providerStatus: response.status,
      providerBody: data,
    });
  }
  return {
    data,
    quota: {
      remaining: response.headers.get('x-requests-remaining'),
      used: response.headers.get('x-requests-used'),
      last: response.headers.get('x-requests-last'),
    },
  };
}

async function mapLimit(items, limit, worker) {
  const results = new Array(items.length);
  let cursor = 0;
  async function runner() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      try { results[index] = { status: 'fulfilled', value: await worker(items[index], index) }; }
      catch (reason) { results[index] = { status: 'rejected', reason }; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, Math.max(1, items.length)) }, runner));
  return results;
}

function outcomeKey(outcome) {
  return Number.isFinite(outcome.point) ? String(outcome.point) : 'no-line';
}

function formatPropEvent(eventOdds, allowedMarkets) {
  const markets = {};
  for (const bookmaker of eventOdds.bookmakers ?? []) {
    for (const market of bookmaker.markets ?? []) {
      if (!allowedMarkets.includes(market.key)) continue;
      markets[market.key] ??= {};
      for (const outcome of market.outcomes ?? []) {
        const playerName = outcome.description?.trim() || outcome.name?.trim();
        if (!playerName) continue;
        markets[market.key][playerName] ??= { playerName, books: {} };
        markets[market.key][playerName].books[bookmaker.key] ??= {
          bookmaker: bookmaker.title,
          lastUpdate: market.last_update ?? bookmaker.last_update ?? null,
          offers: {},
        };
        const book = markets[market.key][playerName].books[bookmaker.key];
        const key = outcomeKey(outcome);
        book.offers[key] ??= { line: Number.isFinite(outcome.point) ? outcome.point : null, outcomes: {} };
        book.offers[key].outcomes[String(outcome.name).toLowerCase()] = { label: outcome.name, americanOdds: outcome.price };
      }
    }
  }
  for (const playerMap of Object.values(markets)) {
    for (const player of Object.values(playerMap)) {
      for (const book of Object.values(player.books)) book.offers = Object.values(book.offers);
    }
  }
  const hasProps = Object.values(markets).some((players) => Object.keys(players).length > 0);
  return {
    gameId: eventOdds.id,
    commenceTime: eventOdds.commence_time,
    homeTeam: eventOdds.home_team,
    awayTeam: eventOdds.away_team,
    matchup: `${eventOdds.away_team} @ ${eventOdds.home_team}`,
    status: hasProps ? 'available' : 'no_props',
    message: hasProps ? null : 'Game is listed, but requested player props are not available yet.',
    markets,
  };
}

function formatFeaturedEvent(event) {
  const markets = {};
  for (const bookmaker of event.bookmakers ?? []) {
    for (const market of bookmaker.markets ?? []) {
      markets[market.key] ??= {};
      markets[market.key][bookmaker.key] = {
        bookmaker: bookmaker.title,
        lastUpdate: market.last_update ?? bookmaker.last_update ?? null,
        outcomes: market.outcomes ?? [],
      };
    }
  }
  return {
    gameId: event.id,
    commenceTime: event.commence_time,
    homeTeam: event.home_team,
    awayTeam: event.away_team,
    matchup: `${event.away_team} @ ${event.home_team}`,
    markets,
  };
}

async function getFeaturedBoard(config) {
  const apiKey = getApiKey();
  const params = new URLSearchParams({ apiKey, regions: REGIONS, markets: FEATURED_MARKETS.join(','), oddsFormat: 'american', dateFormat: 'iso' });
  const { data, quota } = await fetchJson(`${API_BASE}/sports/${config.providerKey}/odds?${params}`);
  if (!Array.isArray(data)) throw Object.assign(new Error('Unexpected featured-odds response.'), { statusCode: 502, code: 'INVALID_PROVIDER_RESPONSE' });
  return { games: data.map(formatFeaturedEvent), quota };
}

async function getPropBoard(config, requestedMarkets = config.propMarkets, options = {}) {
  const apiKey = getApiKey();
  const markets = [...new Set(requestedMarkets)].filter((market) => config.propMarkets.includes(market));
  if (!markets.length) throw Object.assign(new Error('No supported player-prop markets were requested for this sport.'), { statusCode: 400, code: 'NO_SUPPORTED_MARKETS' });

  const eventParams = new URLSearchParams({ apiKey, dateFormat: 'iso' });
  const { data: rawEvents } = await fetchJson(`${API_BASE}/sports/${config.providerKey}/events?${eventParams}`);
  if (!Array.isArray(rawEvents)) throw Object.assign(new Error('Unexpected events response.'), { statusCode: 502, code: 'INVALID_PROVIDER_RESPONSE' });
  const nowMs = Date.now();
  const horizonHours = Math.max(1, Number(options.horizonHours ?? PROP_EVENT_HORIZON_HOURS));
  const maxEvents = Math.max(1, Number(options.maxEvents ?? PROP_MAX_EVENTS));
  const horizonMs = nowMs + horizonHours * 3600_000;
  const eligibleEvents = rawEvents
    .filter((event) => {
      const when = Date.parse(event.commence_time || '');
      return Number.isFinite(when) && when >= nowMs - 3600_000 && when <= horizonMs;
    })
    .sort((a, b) => Date.parse(a.commence_time) - Date.parse(b.commence_time));
  const events = eligibleEvents.slice(0, maxEvents);

  const results = await mapLimit(events, CONCURRENCY, async (event) => {
    const params = new URLSearchParams({ apiKey, regions: REGIONS, markets: markets.join(','), oddsFormat: 'american', dateFormat: 'iso' });
    const response = await fetchJson(`${API_BASE}/sports/${config.providerKey}/events/${event.id}/odds?${params}`);
    return { game: formatPropEvent(response.data, markets), quota: response.quota };
  });

  const games = [];
  const warnings = [];
  if (eligibleEvents.length > events.length) {
    warnings.push({
      code: 'EVENT_CAP_APPLIED',
      message: `Prop requests capped at ${events.length} of ${eligibleEvents.length} eligible events to control provider usage.`,
      eligibleEvents: eligibleEvents.length,
      requestedEvents: events.length,
      horizonHours,
    });
  }
  let quota = null;
  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      games.push(result.value.game);
      quota = result.value.quota;
      return;
    }
    const event = events[index];
    warnings.push({
      gameId: event?.id ?? null,
      matchup: event ? `${event.away_team} @ ${event.home_team}` : null,
      code: result.reason?.code ?? 'EVENT_FETCH_FAILED',
      message: result.reason?.message ?? 'Failed to fetch event props.',
    });
    if (event) games.push({
      gameId: event.id,
      commenceTime: event.commence_time,
      homeTeam: event.home_team,
      awayTeam: event.away_team,
      matchup: `${event.away_team} @ ${event.home_team}`,
      status: 'fetch_error',
      message: 'The game exists, but its player props could not be loaded.',
      markets: {},
    });
  });
  return { requestedMarkets: markets, games, warnings, quota, eventWindow: { horizonHours, maxEvents, eligibleEvents: eligibleEvents.length, fetchedEvents: events.length } };
}

function runPython(args, timeoutMs = 30_000) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.env.PYTHON_BIN || 'python3', args, { cwd: __dirname, env: process.env });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(Object.assign(new Error('Python Layer-5 check timed out.'), { code: 'LAYER5_TIMEOUT' }));
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('error', (error) => { clearTimeout(timer); reject(error); });
    child.on('close', (code) => { clearTimeout(timer); resolve({ code, stdout, stderr }); });
  });
}

async function layer5Status() {
  if (!fs.existsSync(LAYER5_DB_PATH)) {
    return {
      httpStatus: 200,
      body: {
        status: 'NOT_INITIALIZED',
        cleanStart: true,
        databasePath: LAYER5_DB_PATH,
        pricingEnabled: LAYER5_PRICING_ENABLED,
        nextAction: 'Run the Layer-5 bootstrap before genuine canary traffic.',
      },
    };
  }
  const reportPath = path.join(__dirname, 'data', 'layer5_runtime_observe.json');
  const result = await runPython([
    path.join(__dirname, 'layer5', 'layer5_canary.py'),
    '--db', LAYER5_DB_PATH,
    '--mode', 'observe',
    '--report', reportPath,
  ]);
  let report = null;
  try { report = JSON.parse(fs.readFileSync(reportPath, 'utf8')); } catch {}
  return {
    httpStatus: result.code === 0 ? 200 : 503,
    body: {
      status: result.code === 0 ? 'PASS' : 'FAIL',
      cleanStart: true,
      pricingEnabled: LAYER5_PRICING_ENABLED,
      databasePath: LAYER5_DB_PATH,
      report,
      ...(result.code === 0 ? {} : { stderr: result.stderr }),
    },
  };
}

async function route(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (req.method === 'GET' && pathname === '/') {
    return text(res, 200, fs.readFileSync(INDEX_PATH, 'utf8'), 'text/html; charset=utf-8');
  }

  if (req.method === 'GET' && pathname === '/health') {
    return json(res, 200, {
      ok: true,
      service: 'multi-sport-edge-lab',
      supportedSports: listSports().map((sport) => sport.slug),
      dataFeeds: {
        odds: { provider: 'The Odds API', configured: Boolean(process.env.ODDS_API_KEY?.trim()) },
        stats: { provider: 'BALLDONTLIE', configured: isBalldontlieConfigured(), supportedSports: balldontlieSupportedSports() },
      },
      layer5: { databaseExists: fs.existsSync(LAYER5_DB_PATH), pricingEnabled: LAYER5_PRICING_ENABLED, cleanStart: true },
    });
  }

  if (req.method === 'GET' && pathname === '/api/sports') {
    return json(res, 200, {
      sports: listSports(),
      liveOddsConfigured: Boolean(process.env.ODDS_API_KEY?.trim()),
      statsFeedConfigured: isBalldontlieConfigured(),
      statsFeedSports: balldontlieSupportedSports(),
    });
  }

  const featuredMatch = pathname.match(/^\/api\/sports\/([^/]+)\/featured$/);
  if (req.method === 'GET' && featuredMatch) {
    const config = getSportConfig(featuredMatch[1]);
    if (!config) return json(res, 404, { error: { code: 'SPORT_NOT_SUPPORTED', message: 'Sport is not supported.' } });
    return json(res, 200, { sport: config, fetchedAt: new Date().toISOString(), ...(await getFeaturedBoard(config)) });
  }

  const propsMatch = pathname.match(/^\/api\/sports\/([^/]+)\/props$/);
  if (req.method === 'GET' && propsMatch) {
    const config = getSportConfig(propsMatch[1]);
    if (!config) return json(res, 404, { error: { code: 'SPORT_NOT_SUPPORTED', message: 'Sport is not supported.' } });
    const requested = url.searchParams.get('markets')?.split(',').map((value) => value.trim()).filter(Boolean) || config.propMarkets;
    return json(res, 200, { sport: config, fetchedAt: new Date().toISOString(), ...(await getPropBoard(config, requested)) });
  }

  const scanMatch = pathname.match(/^\/api\/sports\/([^/]+)\/scan$/);
  if (req.method === 'GET' && scanMatch) {
    const config = getSportConfig(scanMatch[1]);
    if (!config) return json(res, 404, { error: { code: 'SPORT_NOT_SUPPORTED', message: 'Sport is not supported.' } });
    const requested = url.searchParams.get('markets')?.split(',').map((value) => value.trim()).filter(Boolean) || config.propMarkets;
    const board = await getPropBoard(config, requested);
    const useStats = isBalldontlieConfigured() && balldontlieSupportedSports().includes(config.slug);
    const scan = await scanPropBoard({
      sportConfig: config,
      board,
      maxEnrichment: SCAN_ENRICH_LIMIT,
      enrichPlayer: useStats ? enrichPropWithBalldontlie : null,
      now: new Date(),
    });
    return json(res, 200, {
      sport: config,
      fetchedAt: new Date().toISOString(),
      feeds: {
        odds: { provider: 'The Odds API', configured: true },
        stats: { provider: 'BALLDONTLIE', configured: isBalldontlieConfigured(), activeForSport: useStats },
      },
      quota: board.quota,
      warnings: board.warnings,
      scan,
    });
  }

  if (req.method === 'GET' && pathname === '/api/nfl/props') {
    const config = getSportConfig('nfl');
    return json(res, 200, { sport: config, fetchedAt: new Date().toISOString(), ...(await getPropBoard(config)) });
  }

  if (req.method === 'POST' && pathname === '/api/slip/validate') {
    const body = await readJson(req);
    const result = validateBetSlip(body.legs, body.now ?? new Date(), { sameGameMax: body.sameGameMax });
    return json(res, result.valid ? 200 : 422, result);
  }

  if (req.method === 'POST' && pathname === '/api/props/analyze') {
    const body = await readJson(req);
    try { return json(res, 200, analyzePlayerProp(body)); }
    catch (error) { error.statusCode = 400; error.code = 'INVALID_ANALYSIS_INPUT'; throw error; }
  }

  if (req.method === 'GET' && pathname === '/api/layer5/status') {
    const result = await layer5Status();
    return json(res, result.httpStatus, result.body);
  }

  return json(res, 404, { error: { code: 'NOT_FOUND', message: 'Route not found.' } });
}

const server = http.createServer(async (req, res) => {
  try { await route(req, res); }
  catch (error) {
    console.error(error);
    json(res, error.statusCode || 500, {
      error: {
        code: error.code || 'INTERNAL_SERVER_ERROR',
        message: error.message || 'Unexpected server error.',
        ...(process.env.NODE_ENV !== 'production' && error.providerBody ? { providerBody: error.providerBody } : {}),
      },
    });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Multi-Sport Edge Lab listening on port ${PORT}`);
  console.log(`Layer-5 pricing globally enabled: ${LAYER5_PRICING_ENABLED}`);
});
